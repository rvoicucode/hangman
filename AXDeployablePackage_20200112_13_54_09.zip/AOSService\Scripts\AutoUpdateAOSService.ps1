﻿<#
.SYNOPSIS
    Update the AOS service files.

.DESCRIPTION

    Copyright © 2019 Microsoft. All rights reserved.
#>
[CmdletBinding()]
param
(
    [Parameter(Mandatory = $false, HelpMessage = "The path to the directory in which to write log files.")]
    [string]$LogDir,
    [Parameter(Mandatory = $false, HelpMessage = "Indicate that this is being run on a staging environment.")]
    [switch]$useStaging = $false
)

$ErrorActionPreference = "Stop"
Import-Module WebAdministration
Import-Module "$PSScriptRoot\CommonRollbackUtilities.psm1" -DisableNameChecking
Import-Module "$PSScriptRoot\AosEnvironmentUtilities.psm1" -Force -DisableNameChecking

# Initialize exit code.
[int]$ExitCode = 0

# Initialize the log file to use with Write-ServicingLog.
Set-ServicingLog -LogDir $LogDir -LogFileName "AosService-Update_$([DateTime]::UtcNow.ToString("yyyyMMddHHmmss")).log"

try
{
    Write-ServicingLog "Starting AOS update..."

    if (Test-Path -Path "$($PSScriptRoot)\NonAdminDevToolsInterject.ps1")
    {
        & "$PSScriptRoot\NonAdminDevToolsInterject.ps1"
    }

    if ($useStaging)
    {
        $AosServiceStagingPath = Get-AosServiceStagingPath
        $webroot = Join-Path -Path $AosServiceStagingPath -ChildPath "webroot"
        $aosPackagePath = Join-Path -Path $AosServiceStagingPath -ChildPath "PackagesLocalDirectory"
    }
    else
    {
        $webroot = Get-AosWebSitePhysicalPath
        $aosPackagePath = Get-AOSPackageDirectory

        # Ensure AOS service is stopped.
        # This is a mitigation in case the machine was rebooted or the AOS service started while deployable package.
        Write-ServicingLog "Calling script to stop the AOS..."
        & "$PSScriptRoot\AutoStopAOS.ps1"

        Write-ServicingLog "Terminating other user sessions..."
        KillAllOtherUserSession

        $aosWebServicePath = Get-AosServicePath
        Write-ServicingLog "Terminating processes locking files under AOS service folder..."
        KillProcessLockingFolder -folder $aosWebServicePath
    }

    if ([string]::IsNullOrWhiteSpace($webroot))
    {
        throw "Failed to find the webroot of the AOS Service website at $($webroot), update aborted."
    }

    $ParentPath = Split-Path -Path $PSScriptRoot -Parent
    $source = Join-Path -Path $ParentPath -ChildPath "Code"

    $exclude = @('*.config')
    #region Update the AOS web root
    Write-ServicingLog "Updating AOS service at $($webroot) from $($source)..."

    Get-ChildItem -Path $source -Recurse -Exclude $exclude | Copy-Item -Force -Destination {
        if ($_.GetType() -eq [System.IO.FileInfo])
        {
            Join-Path -Path $webroot -ChildPath $_.FullName.Substring($source.length)
        }
        else
        {
            Join-Path -Path $webroot -ChildPath $_.Parent.FullName.Substring($source.length)
        }
    }
    #endregion

    #region Update SQL ODBC Driver
    Write-ServicingLog "Installing updated SQL ODBC driver if necessary..."
    Invoke-Expression "$PSScriptRoot\InstallUpdatedODBCDriver.ps1 -LogDir:`"$LogDir`""
    #endregion

    #region ALM Service clean copy removal
    $ALMPackagesCopyPath = Get-ALMPackageCopyPath
    if ($ALMPackagesCopyPath)
    {
        $ALMPackagesCopyPath = Join-Path -Path $ALMPackagesCopyPath -ChildPath "Packages"
        if (Test-Path -Path $ALMPackagesCopyPath)
        {
            Write-ServicingLog "Removing ALM Service copy of packages..."
            Invoke-Expression "cmd.exe /c rd /s /q `"$ALMPackagesCopyPath`""
            if ($LastExitCode -ne 0)
            {
                throw [System.Exception] "Error removing ALM Service copy of packages"
            }
        }
    }
    #endregion

    #region Remove module packages
    if (Test-Path -Path "$PSScriptRoot\AutoRemoveAosModule.ps1")
    {
        Write-ServicingLog "Removing module packages..."
        Invoke-Expression "$PSScriptRoot\AutoRemoveAosModule.ps1 -aosPackageDirectory:`"$aosPackagePath`" -LogDir:`"$LogDir`""
    }
    #endregion

    #region Update module packages
    Write-ServicingLog "Installing module packages..."
    Invoke-Expression "$PSScriptRoot\InstallMetadataPackages.ps1 -useStaging:`$$($useStaging) -LogDir:`"$LogDir`""
    #endregion

    # Ensure that a log path exists.
    [string]$logPath = $LogDir
    if ([String]::IsNullOrWhiteSpace($logPath))
    {
        $logPath = "$PSScriptRoot"
    }

    #region CRM SDK assembly removal
    if (Test-Path -Path "$PSScriptRoot\RemoveCrmSdkAssemblies.ps1")
    {
        [string] $dt = [System.DateTime]::Now.ToString("yyyyMMddHHmmss")
        [string] $logfile = Join-Path -Path $logPath -ChildPath "RemoveCrmSdkAssemblies.$dt.log"
        Write-ServicingLog "Removing CRM SDK assemblies..."
        Invoke-Expression "$PSScriptRoot\RemoveCrmSdkAssemblies.ps1 -log:`"$logfile`" -packagesLocalDirectoryPath:`"$aosPackagePath`""
    }
    #endregion

    #region GER Assemblies check
    if (Test-Path -Path "$PSScriptRoot\CheckGERAssemblies.ps1")
    {
        [string] $dt = [System.DateTime]::Now.ToString("yyyyMMddHHmmss")
        [string] $logfile = Join-Path -Path $logPath -ChildPath "CheckGERAssemblies.$dt.log"
        Write-ServicingLog "Checking GER assemblies..."
        Invoke-Expression "$PSScriptRoot\CheckGERAssemblies.ps1 -log:`"$logfile`" -packagesLocalDirectoryPath:`"$aosPackagePath`""
    }
    #endregion

    #region Replace cert loading if necessary
    if (Test-Path -Path "$PSScriptRoot\ReplaceCertificateLoadAssemblies.ps1")
    {
        $dt = [System.DateTime]::Now.ToString("yyyyMMddHHmmss")
        $logFile = Join-Path -Path $logPath -ChildPath "ReplaceCertificateLoadAssemblies.$dt.log"
        Write-ServicingLog "Replacing certificate load assemblies..."
        Invoke-Expression "$PSScriptRoot\ReplaceCertificateLoadAssemblies.ps1 -log:`"$logFile`" -webroot:`"$webroot`""
    }
    #endregion

    #region Blast DbSync binaries
    if (Test-Path -Path "$PSScriptRoot\ReplaceDbSyncBlastAssemblies.ps1")
    {
        $dt = [System.DateTime]::Now.ToString("yyyyMMddHHmmss");
        $logFile = Join-Path -Path $logPath -ChildPath "ReplaceDbSyncBlastAssemblies.$dt.log"
        Write-ServicingLog "Replacing DbSync assemblies..."
        Invoke-Expression "$PSScriptRoot\ReplaceDbSyncBlastAssemblies.ps1 -log:`"$logFile`" -webroot:`"$webroot`" -packagedirectory:`"$aosPackagePath`""
    }
    #endregion
}
catch
{
    # Ensure non-zero exit code if an exception is caught and no exit code set.
    if ($ExitCode -eq 0)
    {
        $ExitCode = 1024
    }

    $ErrorMessage = "Error during AOS update: $($_)"

    Write-ServicingLog $ErrorMessage
    Write-ServicingLog $($_) -Vrb
    Write-ServicingLog "AOS update script failed with exit code: $($ExitCode)."

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $(Get-ServicingLog)]"
}

Write-ServicingLog "AOS update script completed with exit code: $($ExitCode)."
exit $ExitCode
# SIG # Begin signature block
# MIIkoQYJKoZIhvcNAQcCoIIkkjCCJI4CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCc5yKtivUSBZ12
# +3j2pwWJmjVgPX2ZceSIpZYopjLa+aCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWdjCCFnICAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB+TAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgKiFRk9j2
# uhMpsPngNgtFW7/H3Mput6wfrSFtuHcNYf8wgYwGCisGAQQBgjcCAQwxfjB8oF6A
# XABBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBlAHIA
# dgBpAGMAZQBQAGwAYQB0AGYAbwByAG0AVQBwAGQAYQB0AGUAMQAuAHAAcwAxoRqA
# GGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQAVAhic
# vrCU9gLUCefhpNMvlGMdrROgThzMjM+RBpQB5GkANvzy6cAYnU7xVLio+MxOCI9d
# fchneqOYJ2FW+fPWBEiy1bpttqevM3cd07xyIONf13N7MzEwBDwQ8DnnoVtz0047
# AcDH7z1MCBWCR/5ek3JmJ1/CqrZUCrlcaQiyiRde2JMB0WV7rEtF219EKgibYWxp
# HIClhQLMe3sM6j5YKfLp6JlDMJJW4A54BPkWY8ssnKDol1kllrSJ9lJlW1F3xDFy
# 8hVem/jMeov672ErppEOz5anS6lCkDAwUysL626R4at9xftUW2qkilDH83Hkuo5d
# mXdfUGNNlZ6Wim6goYITtTCCE7EGCisGAQQBgjcDAwExghOhMIITnQYJKoZIhvcN
# AQcCoIITjjCCE4oCAQMxDzANBglghkgBZQMEAgEFADCCAVQGCyqGSIb3DQEJEAEE
# oIIBQwSCAT8wggE7AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIJ53
# wAsWnWL+ORuzc+d7qOUD9uCha+8KoYrTKkdoMb8NAgZdr1KhSGUYEjIwMTkxMDIz
# MDY1OTQ4Ljc2WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjE0OEMtQzRCOS0yMDY2
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIPITCCBPUw
# ggPdoAMCAQICEzMAAAEGYbVEmfjq8u0AAAAAAQYwDQYJKoZIhvcNAQELBQAwfDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWlj
# cm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTkwOTA2MjA0MTE5WhcNMjAx
# MjA0MjA0MTE5WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAk
# BgNVBAsTHVRoYWxlcyBUU1MgRVNOOjE0OEMtQzRCOS0yMDY2MSUwIwYDVQQDExxN
# aWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEArr9jwWp0S7dzOEOhiC86flHg/y8uMNR76LWEuelieQtTLK6q
# bd1q+1pgkJTmOohyfCIuq1tOCgqJOfguzcQR41p2KYUm7qKP5+hbGEqcC1oznZxS
# Yk7Ftxc6Sv2cN7g+zB0IF392TPyADRujyD7rNC9nPorjgS0Gh/7TJOCXU70bIaar
# nFIIXEuwnOZckTuRtb+ICoVyX9anc0Mh+YYffzkfYg8pKM5EOqzrVzZDjf3tm0EX
# 1FT/Wvvvf9KHGJ7cpoHamJvehvqvvM+NfPrMcZwtdq0B5BVjzi6UYwdZT/cQ49xe
# NlK5oDMIjMaPVU/vknG6l9zt8/r/LgqaLcCZZwIDAQABo4IBGzCCARcwHQYDVR0O
# BBYEFPnUtdlfjVfnsQVZJgk0CehOb9NMMB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8
# RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNy
# bDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggEBAI6ErWi124Hq21/7/Kvk+rPIMqLX/+VCc3DVgWSIZKZ3RcJPT5/M2TBmjKZd
# ExonX3tr2MOt7FGN8LyzIQ9gKiwKVZ8zJpx3PJ7xALuj5KI1RwzsHYHuGS6U8pH3
# bXyJQBkrBvzq2VYWkLvbHOFmG3hTOvsxWsYporVo4aDWRaVqj2+5rsv8PIl9wrUu
# eNHB2ZPTP1UBCgZ6fnjYPP5A5IM2uPONAsDmQL/vgi3p2qKvpoMdBXK22kF4mk+B
# l+ve1j9VHy4kgxXahC9+jPaYBeF3fgA4eCLCpGzyNZhaMUTF0sOOCh+e8na1MC3P
# QF032qCs9h1PrkrmKTGBgIzAYJ0wggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0G
# CSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3Jp
# dHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
# CgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3
# PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMw
# VyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijG
# GvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/
# 9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9
# pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUB
# BAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcU
# AgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8G
# A1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeG
# RWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUH
# MAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2Vy
# QXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcu
# AzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9k
# b2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwA
# XwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0B
# AQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LF
# Zslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPle
# FzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6
# AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQ
# jP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9Mal
# CpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacR
# y5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo
# +KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZ
# eodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMR
# ZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/
# XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggOvMIIC
# lwIBATCB/qGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28x
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjE0OEMtQzRCOS0yMDY2MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiUKAQEwCQYFKw4DAhoFAAMV
# AGO9+BoeVYVq7hbxu+WwvM9UNfL5oIHeMIHbpIHYMIHVMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0
# aW9ucyBQdWVydG8gUmljbzEnMCUGA1UECxMebkNpcGhlciBOVFMgRVNOOjRERTkt
# MEM1RS0zRTA5MSswKQYDVQQDEyJNaWNyb3NvZnQgVGltZSBTb3VyY2UgTWFzdGVy
# IENsb2NrMA0GCSqGSIb3DQEBBQUAAgUA4VnRLjAiGA8yMDE5MTAyMzAzMDQxNFoY
# DzIwMTkxMDI0MDMwNDE0WjB2MDwGCisGAQQBhFkKBAExLjAsMAoCBQDhWdEuAgEA
# MAkCAQACATUCAf8wBwIBAAICGAwwCgIFAOFbIq4CAQAwNgYKKwYBBAGEWQoEAjEo
# MCYwDAYKKwYBBAGEWQoDAaAKMAgCAQACAwehIKEKMAgCAQACAwehIDANBgkqhkiG
# 9w0BAQUFAAOCAQEAf2wUakAAo/z5MsuZAFunrNi7mpLudRTWETaPsF2KvMCPOtsv
# xYrXDbLornyt/DkLzV3QvvMmRpKHhuKYTnCIZIBszypY6QzboKgj8Fe2M3YyyRCE
# ObGBvWnu8G3XvRLSr/AIkuGp0NE66ALBZmhKdEkHskwD24/jgmCNvQAQAMPf4R2D
# kjfwaHgMiNjMDRbVJOlCdLEcXqhIrPAMBH649B9R5elF9UjTjRPtA3GI1diDHMiI
# h7S5lyXTLOcmdsBnBaSqGCPLeqXVvcy1aibCZke0NfF/BfWNKcVcZlrK64nmzvrT
# L7KsKlknvc377LCh3++6r+hGIrN13BIi8hjm0zGCAvUwggLxAgEBMIGTMHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABBmG1RJn46vLtAAAAAAEGMA0G
# CWCGSAFlAwQCAQUAoIIBMjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJ
# KoZIhvcNAQkEMSIEIFmgP9AowNCxfJudLjBM5ds9j1HayQ9ebXTVArd+mNEOMIHi
# BgsqhkiG9w0BCRACDDGB0jCBzzCBzDCBsQQUY734Gh5VhWruFvG75bC8z1Q18vkw
# gZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAQZhtUSZ
# +Ory7QAAAAABBjAWBBQmBv0/HSDkboWimATQ5TVFlMooIjANBgkqhkiG9w0BAQsF
# AASCAQAzavh8Gg2WqxauuFw+3T/7ZTDQKwUr0Ae0dcXcPCF/AwMeTC7vrGr9jwKP
# Sa3+iraDJy3hisv3SPs8YE0DWU/ozWr71sD+ESAPFghTg00bropqu5GaOtKFqmta
# axbUaURTZ4LqX/9A+fUGBH2OeM2xWKKWBbFtXix8hnLVhyAbKj3vchx3Dj9u4MF7
# A2a3gY8pWrtSJ0trCcmhDlfdHgX1qs1ulqhzBgzvOj+9wZ9LsJ8VPi4oke5Hql1y
# AOJ5fdAH0DtxgChgbPNNTDQhPR4dYpBhIyHEML3CMZN2LC8sUypgcNyqx4Df17DW
# eVv6pkIGrSLk5ADWpgfrykhdHmrZ
# SIG # End signature block
