﻿<#
.SYNOPSIS
    Swap the AOS staging environment to production.

.DESCRIPTION

    Copyright © 2019 Microsoft. All rights reserved.
#>
[CmdletBinding()]
param
(
    [Parameter(Mandatory = $false, HelpMessage = "The path to the directory in which to write log files.")]
    [string]$LogDir,
    [Parameter(Mandatory = $false, HelpMessage = "The ID of the runbook this is executing as part of.")]
    [string]$RunbookId
)

$ErrorActionPreference = "Stop"
Import-Module "$PSScriptRoot\CommonRollbackUtilities.psm1" -DisableNameChecking
Import-Module "$PSScriptRoot\AosEnvironmentUtilities.psm1" -Force -DisableNameChecking

# Initialize the log file to use with Write-ServicingLog.
Set-ServicingLog -LogDir $LogDir

# Initialize exit code.
[int]$ExitCode = 0

# Get the runbook ID
if ([string]::IsNullOrWhiteSpace($RunbookId))
{
    $RunbookId = Get-RunbookId

    #If the runbook ID still wasn't found, set it to a unique value
    if ([string]::IsNullOrWhiteSpace($RunbookId))
    {
        $runbookIdPlaceholder = [DateTime]::UtcNow.Ticks.ToString()
        Write-ServicingLog "Warning: Runbook ID was not specified and could not be determined. Using [$runbookIdPlaceholder] as a temporary Runbook ID."
        $RunbookId = $runbookIdPlaceholder
    }
}

# Progress breadcrumb names
$createStagingCompleted = "CreateAOSStagingEnvCompleted"
$swapStagingStarted = "SwapAOSStagingEnvStarted"
$swapStagingCompleted = "SwapAOSStagingEnvCompleted"

try
{
    <#
        Directories used in this script:
        - <service volume>\AOSServiceStaging
            The initial staging directory pre-swap
        - <service volume>\AOSServiceBackup
            The post-swap backup of the original AOSService folder
        - <service volume>\AOSService
            The current AOSService instance
        - <deployable package root>\RunbookWorkingFolder\<runbook id>\<machine>\AOSService\<step>\Backup\AOSServiceBackup
            The backup location on completion of SwapAOSStagingEnv.ps1
    #>

    Write-ServicingLog "Starting AOS swap staging environment script..."

    $aosWebServicePath = Get-AosServicePath
    $stagingFolder = Get-AosServiceStagingPath
    $backupFolder = Get-AosServiceBackupPath

    #region Initialize script progress tracking
    $progressFileName = "AOSStagingProgress_$($RunbookId).json"
    $progressFileInitial = Join-Path -Path $stagingFolder -ChildPath $progressFileName
    $progressFilePostSwap = Join-Path -Path $aosWebServicePath -ChildPath $progressFileName

    if (Test-Path $progressFilePostSwap)
    {
        # The swap completed so the progress file from the initial creation of AOSServiceStaging should now be in AOSService
        Initialize-ScriptProgress -progressFile $progressFilePostSwap -ErrorAction Continue
    }
    elseif (Test-Path $progressFileInitial)
    {
        # The swap was not started or incomplete so the progress file should still exist in AOSServiceStaging
        Initialize-ScriptProgress -progressFile $progressFileInitial -ErrorAction Continue
    }
    else
    {
        # Not in the expected location. Log warning - this fails later on when checking for successful completion of the staging directory.
        Write-ServicingLog "Warning: unable to detect AOSService staging progress file [$progressFileName] for staging creation."   
    }
    #endregion

    if (Test-Path -Path $stagingFolder)
    {
        # Check that creation of the staging folder completed successfully.
        Write-ServicingLog "Checking for successful AOS staging environment creation..."
        if (Test-ScriptProgress $createStagingCompleted)
        {
            Write-ServicingLog "Detected successful creation of the AOS Staging environment at [$(Get-ScriptProgress $createStagingCompleted)] for runbook [$RunbookId]"
        }
        else 
        {
            # Log warning if the completion breadcrumb was not found 
            # Leave it to the parent runbook to fail on unfulfilled step dependencies
            Write-ServicingLog "Warning: No completion detected for pre-req step CreateAOSStagingEnv."
        }

        Add-ScriptProgress $swapStagingStarted -ErrorAction Continue

        Write-ServicingLog "Terminating watchdog process if running."
        KillWatchdogProcess

        # Ensure AOS service is stopped.
        # This is a mitigation in case the machine was rebooted or the AOS service started while deployable package.
        Write-ServicingLog "Calling script to stop the AOS..."
        & "$PSScriptRoot\AutoStopAOS.ps1"

        Write-ServicingLog "Terminating other user sessions..."
        KillAllOtherUserSession

        Write-ServicingLog "Terminating processes locking files under AOS service folder..."
        KillProcessLockingFolder -folder $aosWebServicePath

        Write-ServicingLog "Terminating watchdog process if running."
        KillWatchdogProcess

        if (Test-Path -Path $backupFolder)
        {
            Write-ServicingLog "Removing existing $($backupFolder) backup folder..."
            Get-ChildItem -Path $backupFolder -Recurse | Remove-Item -Force -Recurse
            Remove-Item -Path $backupFolder -Force
        }

        Write-ServicingLog "Renaming $($aosWebServicePath) to AosServiceBackup..."
        Rename-Item -Path $aosWebServicePath -NewName "AosServiceBackup"

        Write-ServicingLog "Renaming $($stagingFolder) to AosService..."
        Rename-Item -Path $stagingFolder -NewName "AosService"

        # $RunbookBackupFolder and $PSScriptRoot variables are populated directly from runbook.
        $DPBackupFolder = "$RunbookBackupFolder"

        if ([string]::IsNullOrEmpty($DPBackupFolder))
        {
            $DPBackupFolder = Join-Path -Path $PSScriptRoot -ChildPath "ManualAosServiceBackup"
        }

        Write-ServicingLog "Moving $($backupFolder) to $($DPBackupFolder)..."
        Move-Item -Path $backupFolder -Destination $DPBackupFolder -Force

        # Generate installation records.
        Write-ServicingLog "Generating installation records..."
        GenerateMetadataModuleInstallationInfo

        # If the script executed this far, the progress file is now in the swapped location. 
        # Re-initialize progres tracking to the swapped location and write completion.
        Initialize-ScriptProgress -progressFile $progressFilePostSwap -ErrorAction Continue
        Add-ScriptProgress $swapStagingCompleted -ErrorAction Continue
    }
    elseif (Test-ScriptProgress $swapStagingCompleted -ErrorAction SilentlyContinue)
    {
        Write-ServicingLog "Detected staging swap completed at [$(Get-ScriptProgress -ProgressStep $swapStagingCompleted)] for runbook [$($RunbookId)]"
    }
    else
    {
        Write-ServicingLog "Warning: No staging folder found at: $stagingFolder"
    }
}
catch
{
    # Ensure non-zero exit code if an exception is caught and no exit code set.
    if ($ExitCode -eq 0)
    {
        $ExitCode = 1024
    }

    $ErrorMessage = "Error during AOS swap staging: $($_)"

    Write-ServicingLog $ErrorMessage
    Write-ServicingLog $($_) -Vrb
    Write-ServicingLog "AOS swap staging environment script failed with exit code: $($ExitCode)."

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $(Get-ServicingLog)]"
}
finally
{
    # Back up the progress file for this script's execution.
    $backupDir = if ([string]::IsNullOrEmpty($LogDir)) { $PSScriptRoot } else { $LogDir }
    $logTimeSuffix = [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')
    $scriptProgressFileBackup = Join-Path -Path $backupDir -ChildPath "SwapAOSStagingEnv-ProgressBackup-$logTimeSuffix.json"
    Copy-ScriptProgressFile -Destination $scriptProgressFileBackup -ErrorAction Continue
}

Write-ServicingLog "AOS swap staging environment script completed with exit code: $($ExitCode)."
exit $ExitCode
# SIG # Begin signature block
# MIIkowYJKoZIhvcNAQcCoIIklDCCJJACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAQPErgePAGdgOF
# A5cEnW2Xme9HtwACPL6SC7WpfPo5UKCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWeDCCFnQCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB+TAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgwHUrYymD
# q4Q4j/3bMB8LZRTR+r3rcXkp5d/hN45Y9/4wgYwGCisGAQQBgjcCAQwxfjB8oF6A
# XABBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBlAHIA
# dgBpAGMAZQBQAGwAYQB0AGYAbwByAG0AVQBwAGQAYQB0AGUAMQAuAHAAcwAxoRqA
# GGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQAYGdDQ
# xTvh4vFAR7BgLOFmCcXEnV0fMS5UDMsPbhtxMl5CQy6v1mSdVgFxWEY/+30Kv8Jt
# h9Y1fnx+TL23iCtNkwY+7V5hTKK/zjF18MC1HgBHnCnKQsG39j/ZbWRSBj4Rg9Hc
# 1hHPBinmEC3v4Vz/R58o5IjAN1dKYm2mEr8iTFjOqo62tWcguYKCUvFUQRvg/IxD
# xH0Ynp0kt/WHebDo9hMZ5NZAWvYsEmXoSYyRawi0YjwdRdR+t4njLJuFC7mYkYAl
# RCxQfLptYVyiGANnUTZMaF+ZohdRnEVUlS7jy8SbKzwPTPLtNrfjc8Mn6Mcrfkyp
# dncj5kDS2KNdFvCyoYITtzCCE7MGCisGAQQBgjcDAwExghOjMIITnwYJKoZIhvcN
# AQcCoIITkDCCE4wCAQMxDzANBglghkgBZQMEAgEFADCCAVgGCyqGSIb3DQEJEAEE
# oIIBRwSCAUMwggE/AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIKyp
# 4RGsgu3Tb3QER6Mo+HEil6wegRfBJ+UHwGQmUpqsAgZdriV2JbcYEzIwMTkxMDIz
# MDY1OTQ4Ljk2OFowBwIBAYACAfSggdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25z
# IFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpCOEVDLTMwQTQt
# NzE0NDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCDx8w
# ggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3Nv
# ZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2
# NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6
# f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458
# YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJY
# R4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9L
# ZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioK
# MfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8i
# TQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyK
# MZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjR
# PZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNy
# bDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGg
# BgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBA
# BggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABh
# AHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4Fx
# Az2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcI
# K1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/
# HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QTh
# cJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXsh
# bcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXl
# ZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnf
# XXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvs
# xsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch
# 98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu
# 3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8J
# JxzVs341Hgi62jbb01+P3nSISRIwggT1MIID3aADAgECAhMzAAAA/UQsoPE1cgSp
# AAAAAAD9MA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAy
# MDEwMB4XDTE5MDkwNjIwNDEwN1oXDTIwMTIwNDIwNDEwN1owgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpC
# OEVDLTMwQTQtNzE0NDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKJ0Obmm3DlwImjZ
# vt/JPVLGsjW3p8qQ+fT+YWHBrH0PopNWXPapsSbd1+VAhHn9HQslHueP8iEaZFFy
# rbkey2Uou1e1HDFI/fjPKC4le+9Y1fWR7MOsYFB4emREvMppYjnhOtJVbr/r7ojS
# wqbD0Zj0Bl6mTNAwm7BWLOPlje+dBWwZ0Scu+sHNZjPyKMPNmNARxRcviPZezb2O
# O8vta40WZK8V0wYNTdC30jHGqmly/fFE6UKZhVVGFFuYKJVt7t4N+BR62RKqherS
# xfVFEOLsSi2u5KY18OJhmCtUtembSgLU/bOTw/jNG+qh0PZ6ID3FiL+Eah+LFQHY
# h5B6iNMCAwEAAaOCARswggEXMB0GA1UdDgQWBBRyADoqlGOOSUX8BefT5h5tC0wk
# AjAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Rp
# bVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQBC0Xbt7/UiGBC6gB6lwzWa0LMI
# M9dDh1LVVKt8G8oauK0rucFj8dvQDkMmPqUgmC3yzVvSBoasDarYwdG5fhwe2tvv
# L7UA89GZ/Ztl0DwV+WljNf3ZLIEyIF6PNGxOdmcsayQhKlc5O84ZZV3igKDoxyLi
# 6RKkPvMmyTjo6UsFcRhiBzJuLFw/N5lrx5OkKpafISVIqtC9RYnITW7DN35ZREiB
# n3YcVlZXk3f1hQzsjQ0KbYjTy8t/2vjm7KM3KgNaHrQK/8rMwefkJoNQLrYFhD97
# asUtqbNeBCZFlhNr4wzwNrw5eqrkWDVCsAsdBaSHbVUEEBQtn0eCOnIhl4+noYID
# rTCCApUCAQEwgf6hgdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBS
# aWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpCOEVDLTMwQTQtNzE0NDElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIlCgEBMAkGBSsOAwIa
# BQADFQCiiSSQNxNIGZVj1rXkXaIj+aCPNKCB3jCB26SB2DCB1TELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJzAlBgNVBAsTHm5DaXBoZXIgTlRTIEVTTjo0
# REU5LTBDNUUtM0UwOTErMCkGA1UEAxMiTWljcm9zb2Z0IFRpbWUgU291cmNlIE1h
# c3RlciBDbG9jazANBgkqhkiG9w0BAQUFAAIFAOFZ07AwIhgPMjAxOTEwMjIxOTE0
# NTZaGA8yMDE5MTAyMzE5MTQ1NlowdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA4VnT
# sAIBADAHAgEAAgIoLzAHAgEAAgIafDAKAgUA4VslMAIBADA2BgorBgEEAYRZCgQC
# MSgwJjAMBgorBgEEAYRZCgMBoAowCAIBAAIDFuNgoQowCAIBAAIDB6EgMA0GCSqG
# SIb3DQEBBQUAA4IBAQAHoTst145CwtA6ZQfbhzXw90cWv6DChiohDQQh/vi45exW
# moYVy24FIlvOQ598N25/BkCfOmvXwpudaRlvcK7yY/VoMDuvx35DE3v+J9eF7S9y
# ETJKuSfgQtfoe/arlJILSaK7TKCDAZTJuexEYLFj0ql7uQBXvZ6ZtU7VGhLMCIyb
# X77NHtQGfjjvlzcTBKWJ/eSfT8WY50kSQe4s3/CQaTq65yfsym/5lP2xJC+llUIw
# ehtEcPboQgMDIrX32RSQMBAvyhJ8EOEZPA2+DOHAeU8YS5J8jWgGAkPcSakOQcdy
# GCAk6OnW9XSsptIintfY/mlpz1Sh6XAFLJDAcgsTMYIC9TCCAvECAQEwgZMwfDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWlj
# cm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAD9RCyg8TVyBKkAAAAAAP0w
# DQYJYIZIAWUDBAIBBQCgggEyMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAv
# BgkqhkiG9w0BCQQxIgQgooGbADOzFhazVXwql3jmj0ITjIR3rq/uoQnWJhhQJaww
# geIGCyqGSIb3DQEJEAIMMYHSMIHPMIHMMIGxBBSiiSSQNxNIGZVj1rXkXaIj+aCP
# NDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA/UQs
# oPE1cgSpAAAAAAD9MBYEFE2HiaMh3hKhgIui6rwQsB6oqkgUMA0GCSqGSIb3DQEB
# CwUABIIBAHHRLFfhpZNwIRefTom8Q0uInYDzIpN4d4fDrM2W88OJkLRJnaHRRHc2
# 65VyXRe+EA829R37k8mjdlTI4NgdCKw0rKSqZDJYqYwvasA1FB4EKR7eX8aEbLN7
# E/EDPticSns5ILZrcijEURhHLWKr2Bze/EgsofsHLP9+YLMo+TKa8mzw7bHBLLzw
# GojAkkh3/szQQ4lBvpzIJM/i0B2OVaMFEEoArjuI1eOag2qndrJzF6GsyT/VldmE
# 0xFwEskEcDGirjJYt8dNVLylOyYH29Fpd/OL8dPY3FHDwT3OT+10MfA/EoG2KgF8
# 7z3CusJW2Yl+TUlX/veVOdsjZ6qjtFw=
# SIG # End signature block
