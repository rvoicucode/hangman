﻿<#
.SYNOPSIS
    Restore the ETW manifest files in the instrumentation folder from a backup.

.DESCRIPTION
    The script will stop the Monitoring Agent, unregister the existing ETW manifest files in the
    instrumentation folder, restore the ETW manifests from a previous backup, and run the
    MonitoringInstall scheduled task to register the updated ETW manifests and start the Monitoring
    Agent. MonitoringInstall-Servicing.psm1 must exist in the script folder.

    Exit codes:
       0: Success.
       2: Monitoring PowerShell module could not be initialized.
       4: Monitoring Agent could not be stopped.
       8: Monitoring Agent could not be started.
      16: One or more manifest files could not be removed.
      32: One or more manifest files could not be restored.
    1024: Unknown error.

    Copyright © 2019 Microsoft. All rights reserved.
#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory = $false, HelpMessage = "The maximum number of seconds to wait for the stop tasks to complete.")]
    [int]$StopTaskMaxWaitSec = 300,
    [Parameter(Mandatory = $false, HelpMessage = "The maximum number of seconds to wait for the start task to complete. Set to 0 to not wait.")]
    [int]$StartTaskMaxWaitSec = 300,
    [Parameter(Mandatory = $false, HelpMessage = "The path to the log directory in which output should be written.")]
    [string]$LogDir
)

# Initialize exit code.
[int]$ExitCode = 0

# Initialize Monitoring module and logging.
[string]$LogPath = $null
try
{
    if ($LogDir)
    {
        # Add log file name.
        $LogPath = Join-Path -Path $LogDir -ChildPath "Monitoring-EtwRestore_$([DateTime]::UtcNow.ToString("yyyyMMddHHmmss")).log"

        if ([System.IO.Path]::IsPathRooted($LogPath))
        {
            # Ensure that the directory exists.
            $LogParentPath = Split-Path -Path $LogPath -Parent
            if (!(Test-Path -Path $LogParentPath -ErrorAction SilentlyContinue))
            {
                New-Item -Path $LogParentPath -ItemType "Directory" | Out-Null
            }
        }
        else
        {
            # Resolve relative path under current directory.
            $LogPath = Join-Path -Path $PSScriptRoot -ChildPath $LogPath
        }
    }

    $MonitoringModulePath = Join-Path -Path $PSScriptRoot -ChildPath "MonitoringInstall-Servicing.psm1"
    if (!(Test-Path -Path $MonitoringModulePath -ErrorAction SilentlyContinue))
    {
        throw "Monitoring servicing module not found at: $($MonitoringModulePath)"
    }

    # Import Monitoring module.
    Import-Module -Name $MonitoringModulePath

    # For Monitoring Write-Message - Set log file path.
    Set-WriteMessageLogFilePath -Path $LogPath
}
catch
{
    $ExitCode = 2
    $ErrorMessage = "Error initializing Monitoring PowerShell module from '$($MonitoringModulePath)': $($_)"

    # Use Write-Output since Write-Message is defined in module that could not be loaded.
    Write-Output "$([DateTime]::UtcNow.ToString("yyyy-MM-dd HH:mm:ss")): $($ErrorMessage)"
    Write-Output "$($_.ScriptStackTrace)"
    Write-Output "$($_.Exception)"

    # If a log path was defined, also write error message to it.
    if ($LogPath)
    {
        "$([DateTime]::UtcNow.ToString("yyyy-MM-dd HH:mm:ss")): $($ErrorMessage)" | Out-File -FilePath $LogPath -Append
        "$($_.ScriptStackTrace)" | Out-File -FilePath $LogPath -Append
        "$($_.Exception)" | Out-File -FilePath $LogPath -Append
        "ETW restore script failed with exit code: $($ExitCode)." | Out-File -FilePath $LogPath -Append
    }

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $($LogPath)]"
}

try
{
    Write-Message "Script to restore Monitoring ETW manifest files starting..."
    Write-Message "Command: $(@([Environment]::GetCommandLineArgs()) -join " ")" -Vrb

    # Set backup path. If the RunbookBackupFolder variable is not set, use ManualETWManifestBackup folder.
    $BackupFolder = $RunbookBackupFolder
    if (!$BackupFolder)
    {
        $BackupFolder = Join-Path -Path $PSScriptRoot -ChildPath "ManualETWManifestBackup"
    }

    Write-Message "ETW manifest backup path: $($BackupFolder)"

    # Check if there are any files to restore.
    [bool]$RestoreApplicable = $true
    if (Test-Path -Path $BackupFolder -ErrorAction SilentlyContinue)
    {
        $BackupFiles = @(Get-ChildItem -Path $BackupFolder -File)
        if ($BackupFiles.Count -eq 0)
        {
            $RestoreApplicable = $false
            Write-Message "ETW manifest backup path does not contain any files. Skipping ETW manifest restore step."
        }
    }
    else
    {
        $RestoreApplicable = $false
        Write-Message "ETW manifest backup path does not exist. Skipping ETW manifest update step."
    }

    # If applicable, unregister ETW events, stop agent, restore manifest files, register ETW events, and start agent.
    if ($RestoreApplicable)
    {
        # Stop the Monitoring Agent ETW sessions and agent processes.
        try
        {
            Write-Message "Stopping Monitoring Agent..."
            Stop-MonitoringAgent -MaxWaitSec $StopTaskMaxWaitSec -LogPath $LogDir -SkipIfNotInstalled
        }
        catch
        {
            # Set exit code to indicate Monitoring Agent could not be stopped.
            $ExitCode = 4

            # Throw to terminate script.
            throw
        }

        $ErrorMessages = @()

        # Restarting the EventLog service can prevent some locked file issues.
        Write-Message "Restarting EventLog service..." -Vrb
        try
        {
            Restart-Service -Name "EventLog" -Force
        }
        catch
        {
            Write-Message "Warning: Failed to restart EventLog service: $($_)" -Vrb
        }

        # Get Monitoring manifest path.
        $MonManifestPath = Get-MonitoringManifestPath
        if (!$MonManifestPath)
        {
            $MonManifestPath = Get-MonitoringManifestPathDefault
            Write-Message "Warning: No Monitoring Manifest path found in registry. Using default: $($MonManifestPath)" -Vrb
        }

        Write-Message "Monitoring manifest path: $($MonManifestPath)"

        if (!(Test-Path -Path $MonManifestPath -ErrorAction SilentlyContinue))
        {
            Write-Message "Monitoring manifest path was not found. Creating new directory: $($MonManifestPath)" -Vrb
            New-Item -ItemType Directory -Path $MonManifestPath | Out-Null
        }

        # Remove files from Monitoring manifest folder.
        $RemoveFiles = @(Get-ChildItem -Path $MonManifestPath -File)
        $RemoveErrors = @()
        Write-Message "Removing $($RemoveFiles.Count) files from Monitoring manifest folder..."
        foreach ($File in $RemoveFiles)
        {
            Write-Message "- [Removing] $($File.Name)" -Vrb

            [int]$Attempt = 1
            [int]$MaxAttempts = 3
            while ($Attempt -le $MaxAttempts)
            {
                try
                {
                    Remove-Item -Path $($File.FullName) -Force
                }
                catch
                {
                    if ($Attempt -lt $MaxAttempts)
                    {
                        Write-Message "- [Warning - $($Attempt)]: Failed to remove $($File.Name): $($_.Exception.Message)." -Vrb
                        Start-Sleep -Second 1
                    }
                    else
                    {
                        Write-Message "- [Error]: Failed all attempts to remove $($File.FullName): $($_.Exception.Message)." -Vrb
                        $RemoveErrors += $File
                    }
                }

                $Attempt++
            }
        }

        if ($RemoveErrors.Count -gt 0)
        {
            Write-Message "Error: Failed to remove $($RemoveErrors.Count) files from Monitoring manifest folder."
            $ErrorMessages += "Failed to remove $($RemoveErrors.Count) files from Monitoring manifest folder."
            $ExitCode = $ExitCode -bor 16
        }
        else
        {
            Write-Message "Manifest files were all removed from: $($MonManifestPath)"
        }

        # Restore Monitoring manifest folder from backup (no subfolders).
        $RestoreFiles = @(Get-ChildItem -Path $BackupFolder -File)
        $RestoreErrors = @()
        Write-Message "Restoring $($RestoreFiles.Count) files to Monitoring manifest folder..."
        foreach ($File in $RestoreFiles)
        {
            $DestinationFilePath = Join-Path -Path $MonManifestPath -ChildPath $($File.Name)
            Write-Message "- [Restoring] $($File.Name)" -Vrb

            [int]$Attempt = 1
            [int]$MaxAttempts = 3
            while ($Attempt -le $MaxAttempts)
            {
                try
                {
                    Copy-Item -Path $($File.FullName) -Destination $DestinationFilePath -Force
                }
                catch
                {
                    if ($Attempt -lt $MaxAttempts)
                    {
                        Write-Message "- [Warning - $($Attempt)]: Failed to restore $($File.Name): $($_.Exception.Message)." -Vrb
                        Start-Sleep -Second 1
                    }
                    else
                    {
                        Write-Message "- [Error]: Failed all attempts to restore $($File.FullName): $($_.Exception.Message)." -Vrb
                        $RestoreErrors += $File
                    }
                }

                $Attempt++
            }
        }

        if ($RestoreErrors.Count -gt 0)
        {
            Write-Message "Error: Failed to restore $($RestoreErrors.Count) files to Monitoring manifest folder."
            $ErrorMessages += "Failed to restore $($RestoreErrors.Count) files to Monitoring manifest folder."
            $ExitCode = $ExitCode -bor 32
        }
        else
        {
            Write-Message "Manifest files were all restored to: $($MonManifestPath)"
        }

        # Start the MonitoringInstall task.
        try
        {
            Write-Message "Starting Monitoring Agent..."
            Start-MonitoringAgent -MaxWaitSec $StartTaskMaxWaitSec -SkipIfNotInstalled
        }
        catch
        {
            Write-Message "Error: Failed to start Monitoring Agent: $($_)"
            $ErrorMessages += "Failed to start Monitoring Agent: $($_)"

            # Set exit code to indicate Monitoring Agent could not be started.
            $ExitCode = $ExitCode -bor 8
        }

        # Throw exception with error messages.
        if ($ErrorMessages.Count -gt 0)
        {
            $ErrorMessage = [string]::Join("; ", $ErrorMessages)
            throw $ErrorMessage
        }
    }
}
catch
{
    # Ensure non-zero exit code if an exception is caught and no exit code set.
    if ($ExitCode -eq 0)
    {
        $ExitCode = 1024
    }

    $ErrorMessage = "Error during ETW restore: $($_)"

    Write-Message $ErrorMessage
    Write-Message "$($_.ScriptStackTrace)" -Vrb
    Write-Message "$($_.Exception)" -Vrb
    Write-Message "ETW restore script failed with exit code: $($ExitCode)."

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $($LogPath)]"
}

Write-Message "ETW restore script completed with exit code: $($ExitCode)."
exit $ExitCode
# SIG # Begin signature block
# MIIj0AYJKoZIhvcNAQcCoIIjwTCCI70CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAHz+5SSboXAEZV
# zSTaIoAePy/zGqPVCH4TlJOInRDgVqCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVpTCCFaECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB+TAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgtU46WmVt
# xo/cB5XTNh92liuN23IT0WZHJy456/ee8NQwgYwGCisGAQQBgjcCAQwxfjB8oF6A
# XABBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBlAHIA
# dgBpAGMAZQBQAGwAYQB0AGYAbwByAG0AVQBwAGQAYQB0AGUAMQAuAHAAcwAxoRqA
# GGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQCOcs3n
# mVK+RK06pJ3uKMRQrMXg5TAKn9I7tTzyv0jLpZKsgivWt/FIOkDHYDSag+wdMxFZ
# kQ/i4Z45zpVbfUPx/TdbtyK3DN/fg+0yU8fPlnzHklQUL8rITRKfZpdYNPmCU84Q
# 21Wqk4O9pfFfVRGg6Av62Lgb50hF31Zm5WsgGRnV0pAN3v/zd3XkPKPow8P2D1LG
# JKD3ibwj5lq+PP4bg+YIhLB4mLS1JOd5TN/OBcM5lDS10iyRKWE89jRlEU9x1c/y
# CIR23CWtgENMXwKZrndfLq/L1ll7vg+SWz9XnV8UQXnnro8GBWeVRF90roc17DpO
# CeiM7hX35hGdtBNXoYIS5DCCEuAGCisGAQQBgjcDAwExghLQMIISzAYJKoZIhvcN
# AQcCoIISvTCCErkCAQMxDzANBglghkgBZQMEAgEFADCCAVAGCyqGSIb3DQEJEAEE
# oIIBPwSCATswggE3AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIHVC
# ElGGF/FQNhDJNZhJkH12NaQaa7svt54j5y3xsOpqAgZdjg9TeqcYEjIwMTkxMDIz
# MDY1OTQ5LjUxWjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0
# aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046N0JGMS1FM0VBLUI4MDgxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wggg48MIIE8TCCA9mg
# AwIBAgITMwAAAPasz3Yqc3Sa2gAAAAAA9jANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODEwMjQyMTE0MjdaFw0yMDAxMTAy
# MTE0MjdaMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUw
# IwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjo3QkYxLUUzRUEtQjgwODElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAJSatUDAMe3HeuxWmm5YPMLxNcQBe2YBQPrrf05/RXoBhqge4ulQpIT3pU0n
# yUd8hXpBfRN0sPmT9iHHsyr26+T17dEr7Z+QagRq2CtvlxZI7IyDc187BNfknmCZ
# E9OIZDMJhfF0aYXrMQjDFE25Zvi1RCRa2KuSCCQpqNZJ/Wzg0tlqrXzP0/k/q1Sg
# EXmB1d2EI0KVVua8f+jvrN7MUBSje+zvJPrvyP6Vjp1cC+ACQeFqJy4lZUUhbA/E
# uJk27Z6tbzFIvsZaWef+PaYYs8u76+XBHJa8oA2w663wtEtT8qKA4fbZpdQ1GG2q
# PyZ9ngiRR6DdDQR84BHn6WxtB1UCAwEAAaOCARswggEXMB0GA1UdDgQWBBQdh2KD
# lB9ogklI02zumWSD7CbzSjAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVt
# VTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8E
# AjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAwFfbO
# 4hxXFtCYkdXyHtndu+3IbwPxmKj5+C8AE5uZqStOkDAap0g3UGejDQkDPhzHKIuO
# eWrUoXEnITIIiB244aYV4/9AbVLmj0Ilm5NOyf7B4uzvvI0Ht1d7wx7D09/SeS5A
# Zqf41nazkDTYULLVDfArcohBnpBciOwUugvZGEnnbaxk2BQj1uTiXJ8wl6MMyCfK
# JZjivFkeNaTEY2g/wp64n84nNWkf2B8HzpnvcrBniMt2nMXf/CXae7+IhTfU1Vuh
# p8+1yeAOFTSoojo8P5UQ/4dyZq6F/gJO/SwOTSRAGqpCyJ4hgqnVCN/KCO7juKmk
# 7dgS9lWe+fbbwg7WMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkd
# Dbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMn
# BDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq
# 9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8
# RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v
# 0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN
# /LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYI
# KwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMv
# ZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwA
# aQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIB
# AAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4
# vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3Tv
# QhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8
# z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVK
# C5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhqu
# BEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF
# 0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+
# YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt
# 6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0Mkvf
# Y3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgv
# vM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICzjCCAjcCAQEwgfih
# gdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAj
# BgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjdCRjEtRTNFQS1CODA4MSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQAPF0fCe9YDN8Ja05vz
# yFub9VaakaCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0G
# CSqGSIb3DQEBBQUAAgUA4VornTAiGA8yMDE5MTAyMzA5MzAwNVoYDzIwMTkxMDI0
# MDkzMDA1WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDhWiudAgEAMAoCAQACAhE5
# AgH/MAcCAQACAhHBMAoCBQDhW30dAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisG
# AQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQAD
# gYEABeq2sEg7fvz4SnRU8MaPNypteScJTNcqumqopXRhV4a2ZGtVHwl1mgDBejsI
# bYcpm1XJ4FFE74JKb1+dUERRrQaXrcMjsFJQ3ZAj9aZdXvno62o5UIHJ4zD4hp3K
# cZAGTod5S1upEb71MuLJLawerGLU2pI6HDQaphhlb97lFPQxggMNMIIDCQIBATCB
# kzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAPasz3Yqc3Sa2gAA
# AAAA9jANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJ
# EAEEMC8GCSqGSIb3DQEJBDEiBCDfecMcgDv3JgtK3AQOpoCWAi4/5sQte0M5Iz5c
# Hl39gTCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIPeHQXdqtO0XCdnTJeM9
# 5oARUlabYpUWD6mQTnEvk7TqMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTACEzMAAAD2rM92KnN0mtoAAAAAAPYwIgQgRTAa7ZcVl7hTX8vpXNBm
# YTAciKnCopuvtmVNoDS+AswwDQYJKoZIhvcNAQELBQAEggEAG33cfgosx3cFSZ1V
# QjPbjpEAGXyh1btcmdFSArsfPMH235THzj8WOVEmPu7KTbAhCXV/BxDjDpJfuMhQ
# ZwSsZhef7tWEKFOzt9AEAzIfEtrho1wXQBxm1juM5o7cS+lqZ70vhBljjuHsJn/J
# 0wm6p6vvkWxTstkZ99266UB0y7VQ7V93ot069OIbDSi8I8Air/Q3KZ1HpDllJzth
# 68spsmbXBh9JpbeOAhBoTH8A6O2OyQQmoMe6K4UPCWqRk6YN8jHFLdH5lxOwRvsb
# zrqTMYjTO/Kn72124YorvTYBNWeU5SmhE7wlaZ8CANB1T6OEkUa7pIEMqehks8QZ
# fuaCzw==
# SIG # End signature block
