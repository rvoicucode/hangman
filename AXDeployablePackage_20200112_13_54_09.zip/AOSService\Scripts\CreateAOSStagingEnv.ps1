﻿<#
.SYNOPSIS
    Create the AOS staging environment.

.DESCRIPTION

    Copyright © 2019 Microsoft. All rights reserved.
#>
[CmdletBinding()]
param
(
    [Parameter(Mandatory = $false, HelpMessage = "The path to the directory in which to write log files.")]
    [string]$LogDir,
    [Parameter(Mandatory = $false, HelpMessage = "The ID of the runbook this is executing as part of.")]
    [string]$RunbookId
)

function PrepareDeltaDBsyncReportDeployment([string]$metadataPackagePath)
{
    $MetadataParentPath = Split-Path -Path $metadataPackagePath -Parent
    $deltaSyncFolder = Join-Path -Path $MetadataParentPath -ChildPath "DeltaSync"

    if (!(Test-Path -Path $deltaSyncFolder))
    {
        Write-ServicingLog "Creating delta sync folder." -Vrb
        New-Item -Path $deltaSyncFolder -ItemType Directory -Force | Out-Null
    }
    else
    {
        Write-ServicingLog "Deleting delta sync folder contents." -Vrb
        Get-ChildItem -Path $deltaSyncFolder | Remove-Item -Force -Recurse
    }

    Write-ServicingLog "Copying MD files from metadata package folder to delta sync folder." -Vrb
    Robocopy.exe $metadataPackagePath $deltaSyncFolder /s *AXSecurity*.md *AXTable*.md *AXView*.md *AXEdt*.md *.rdl  >$null
    Write-ServicingLog "Copying MD files completed with RoboCopy exit code $($LASTEXITCODE)." -Vrb
}

$ErrorActionPreference = "Stop"
Import-Module "$PSScriptRoot\CommonRollbackUtilities.psm1" -DisableNameChecking
Import-Module "$PSScriptRoot\AosEnvironmentUtilities.psm1" -Force -DisableNameChecking

# Initialize the log file to use with Write-ServicingLog.
Set-ServicingLog -LogDir $LogDir

# Initialize exit code.
[int]$ExitCode = 0

# Get the runbook ID
if ([string]::IsNullOrWhiteSpace($RunbookId))
{
    $RunbookId = Get-RunbookId

    #If the runbook ID still wasn't found, set it to a unique value
    if ([string]::IsNullOrWhiteSpace($RunbookId))
    {
        $runbookIdPlaceholder = [DateTime]::UtcNow.Ticks.ToString()
        Write-ServicingLog "Warning: Runbook ID was not specified and could not be determined. Using [$runbookIdPlaceholder] as a temporary Runbook ID."
        $RunbookId = $runbookIdPlaceholder
    }
}

# Progress breadcrumb names
$copyStagingStarted = "CopyToStagingStarted"
$copyStagingCompleted = "CopyToStagingCompleted"
$prepareDeltaSyncCompleted = "PrepareDeltaSyncReportCompleted"
$upgradeConfigCompleted = "UpgradeConfigAosServiceCompleted"
$updateAosCompleted = "UpdateAosServiceCompleted"
$overallCompleted = "CreateAOSStagingEnvCompleted"

try
{
    Write-ServicingLog "Starting AOS create staging environment script..."
    $aosWebServicePath = Get-AosServicePath
    $aosWebServiceStagingPath = Get-AosServiceStagingPath
    $packagePath = Join-Path -Path $aosWebServiceStagingPath -ChildPath "PackagesLocalDirectory"
    
    $progressFileNameFormat = "AOSStagingProgress_{0}.json"
    $script:progressFilePath = Join-Path -Path $aosWebServiceStagingPath -ChildPath ($progressFileNameFormat -f $RunbookId)

    if (!(Test-Path -Path $aosWebServiceStagingPath))
    {
        Write-ServicingLog "Creating AOS staging folder." -Vrb
        New-Item -Path $aosWebServiceStagingPath -ItemType Directory -Force | Out-Null
    }
    else
    {
        Write-ServicingLog "Detected AOS Staging folder '$aosWebServiceStagingPath'."
    }

    Initialize-ScriptProgress -progressFile $script:progressFilePath -Scope "Global" -ErrorAction Continue
    Add-ScriptProgress $copyStagingStarted -ErrorAction Continue
    
    if (Test-ScriptProgress $copyStagingCompleted -ErrorAction SilentlyContinue)
    {
        Write-ServicingLog "Detected the previous copy to staging completed at [$(Get-ScriptProgress $copyStagingCompleted)] for runbook [$RunbookId]. Skipping copy."
    }
    else
    {
        Write-ServicingLog "Copying AOS folder to AOS staging folder."
        Copy-FullFolder -SourcePath $aosWebServicePath -DestinationPath $aosWebServiceStagingPath
        Add-ScriptProgress $copyStagingCompleted -ErrorAction Continue
    }

    # Attempt to clean up any progress files copied over from previous runs
    Get-ChildItem $aosWebServiceStagingPath -Filter ($progressFileNameFormat -f "*") -File | ForEach-Object {
        if ($_.Name -ne ($progressFileNameFormat -f $RunbookId))
        {
            Write-Host "Removing progress file from a previous run [$($_.Name)]"
            Remove-Item -Path $_.FullName -Force -ErrorAction Continue
        }
    }
    
    # Prepare delta dbsyc / report deployment
    if (Test-ScriptProgress $prepareDeltaSyncCompleted)
    {
        Write-ServicingLog "Detected PrepareDeltaDBSyncReportDeployment previously completed at [$(Get-ScriptProgress $prepareDeltaSyncCompleted)] for runbook [$RunbookId]. Skipping."
    }
    else 
    {
        Write-ServicingLog "Invoking PrepareDeltaDBSyncReportDeployment function."
        PrepareDeltaDBsyncReportDeployment -metadataPackagePath:$packagePath
        Add-ScriptProgress $prepareDeltaSyncCompleted -ErrorAction Continue
    }
    
    # Update the web.config
    if (Test-ScriptProgress $upgradeConfigCompleted)
    {
        Write-ServicingLog "Detected updating AOSService configuration previously completed at [$(Get-ScriptProgress $upgradeConfigCompleted)] for runbook [$RunbookId]. Skipping."
    }
    else 
    {
        Write-ServicingLog "Invoking AutoUpgradeConfigAosServicePlatformUpdate3.ps1 script."
        Invoke-Expression "$PSScriptRoot\AutoUpgradeConfigAosServicePlatformUpdate3.ps1 -useStaging"
        Write-ServicingLog "Completed AutoUpgradeConfigAosServicePlatformUpdate3.ps1 script with exit code: $($LASTEXITCODE)." -Vrb
        Add-ScriptProgress $upgradeConfigCompleted -ErrorAction Continue
    }

    # Update AOSService
    if (Test-ScriptProgress $updateAosCompleted)
    {
        Write-ServicingLog "Detected updating AOSService previously completed at [$(Get-ScriptProgress $updateAosCompleted)] for runbook [$RunbookId]. Skipping."
    }
    else
    {
        # Do not pass LogDir to AutoUpdateAosService to keep output going to the current log file.
        Write-ServicingLog "Invoking AutoUpdateAosService.ps1 script."
        Invoke-Expression "$PSScriptRoot\AutoUpdateAosService.ps1 -useStaging"
        Write-ServicingLog "Completed AutoUpdateAosService.ps1 script with exit code: $($LASTEXITCODE)." -Vrb
        Add-ScriptProgress $updateAosCompleted -ErrorAction Continue
    }

    # Indicates the script logic has completed - ensure this stays the last line of the execution block.
    Add-ScriptProgress $overallCompleted -ErrorAction Continue
}
catch
{
    # Ensure non-zero exit code if an exception is caught and no exit code set.
    if ($ExitCode -eq 0)
    {
        $ExitCode = 1024
    }

    $ErrorMessage = "Error during AOS create staging: $($_)"

    Write-ServicingLog $ErrorMessage
    Write-ServicingLog $($_) -Vrb
    Write-ServicingLog "AOS create staging environment script failed with exit code: $($ExitCode)."

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $(Get-ServicingLog)]"
}
finally
{
    # Back up the progress file for this script's execution.
    $backupDir = if ([string]::IsNullOrEmpty($LogDir)) { $PSScriptRoot } else { $LogDir }
    $logTimeSuffix = [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')
    $scriptProgressFileBackup = Join-Path -Path $backupDir -ChildPath "CreateAOSStagingEnv-ProgressBackup-$logTimeSuffix.json"
    Copy-ScriptProgressFile -Destination $scriptProgressFileBackup -ErrorAction Continue
}

Write-ServicingLog "AOS create staging environment script completed with exit code: $($ExitCode)."
exit $ExitCode
# SIG # Begin signature block
# MIIkogYJKoZIhvcNAQcCoIIkkzCCJI8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCaAqFXcTBCIYZB
# 6Fs+gsma+otuIhRdOfUVqWgml/EtAqCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWdzCCFnMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB+TAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgxu6mFjNr
# 4zMEj+vPNUJ6qyNfvuHw58EAM8+3wgH+iiIwgYwGCisGAQQBgjcCAQwxfjB8oF6A
# XABBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBlAHIA
# dgBpAGMAZQBQAGwAYQB0AGYAbwByAG0AVQBwAGQAYQB0AGUAMQAuAHAAcwAxoRqA
# GGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQAv1DzJ
# rXTro9oKO8EWDgbMgEgzt149NhIjHs6qYznFjisJROq7ci1tN33GAIITHrv3DhiU
# YxYeyf6SyyhGygdTGutfC4eZFrO/sue4A5cMmP4GVQH4YGIcGGLnJLTo+7g21i36
# A/5YHqXr6Pvv4MMTw20EwfkdfbB2kXQpLIkM9pL2Wg6UTmKSHgZRJlkxaZmvp+5/
# PEtXovKhyhZbm6GWi0llUJDHTxefyASczyqxWGNgUJPxxXtC7QqlocBlXJPghV/T
# IKDUcsHiywCTOeyNNqVXzKwl+WwMWpdGxU3f4wWPEgOzGjtFqQtyB0jWglLHf+C8
# tMJoIhPZ8DkzYN3roYITtjCCE7IGCisGAQQBgjcDAwExghOiMIITngYJKoZIhvcN
# AQcCoIITjzCCE4sCAQMxDzANBglghkgBZQMEAgEFADCCAVUGCyqGSIb3DQEJEAEE
# oIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIGg6
# 6OEPX7PAHgonxygaR8p6MC5FufgTAPKYrbIfwVIaAgZdr1KhSGYYEzIwMTkxMDIz
# MDY1OTQ5LjAwNFowBIACAfSggdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoxNDhDLUM0QjktMjA2
# NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCDyEwggT1
# MIID3aADAgECAhMzAAABBmG1RJn46vLtAAAAAAEGMA0GCSqGSIb3DQEBCwUAMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE5MDkwNjIwNDExOVoXDTIw
# MTIwNDIwNDExOVowgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYw
# JAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoxNDhDLUM0QjktMjA2NjElMCMGA1UEAxMc
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQAD
# ggEPADCCAQoCggEBAK6/Y8FqdEu3czhDoYgvOn5R4P8vLjDUe+i1hLnpYnkLUyyu
# qm3davtaYJCU5jqIcnwiLqtbTgoKiTn4Ls3EEeNadimFJu6ij+foWxhKnAtaM52c
# UmJOxbcXOkr9nDe4PswdCBd/dkz8gA0bo8g+6zQvZz6K44EtBof+0yTgl1O9GyGm
# q5xSCFxLsJzmXJE7kbW/iAqFcl/Wp3NDIfmGH385H2IPKSjORDqs61c2Q4397ZtB
# F9RU/1r773/Shxie3KaB2pib3ob6r7zPjXz6zHGcLXatAeQVY84ulGMHWU/3EOPc
# XjZSuaAzCIzGj1VP75Jxupfc7fP6/y4Kmi3AmWcCAwEAAaOCARswggEXMB0GA1Ud
# DgQWBBT51LXZX41X57EFWSYJNAnoTm/TTDAfBgNVHSMEGDAWgBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29m
# dC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5j
# cmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAM
# BgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUA
# A4IBAQCOhK1otduB6ttf+/yr5PqzyDKi1//lQnNw1YFkiGSmd0XCT0+fzNkwZoym
# XRMaJ197a9jDrexRjfC8syEPYCosClWfMyacdzye8QC7o+SiNUcM7B2B7hkulPKR
# 9218iUAZKwb86tlWFpC72xzhZht4Uzr7MVrGKaK1aOGg1kWlao9vua7L/DyJfcK1
# LnjRwdmT0z9VAQoGen542Dz+QOSDNrjzjQLA5kC/74It6dqir6aDHQVyttpBeJpP
# gZfr3tY/VR8uJIMV2oQvfoz2mAXhd34AOHgiwqRs8jWYWjFExdLDjgofnvJ2tTAt
# z0BdN9qgrPYdT65K5ikxgYCMwGCdMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjAN
# BgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9y
# aXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2
# tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZz
# MFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24o
# xhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5n
# f/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9Nxk
# vaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcV
# AQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAf
# BgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNS
# b29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0Nl
# ckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3
# LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kv
# ZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBs
# AF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcN
# AQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPC
# xWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5
# Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbK
# egBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplm
# kIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTG
# pQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGn
# Ecua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd4
# 6PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1V
# mXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5Kpqj
# EWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsN
# v11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYIDrzCC
# ApcCAQEwgf6hgdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNv
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoxNDhDLUM0QjktMjA2NjElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIlCgEBMAkGBSsOAwIaBQAD
# FQBjvfgaHlWFau4W8bvlsLzPVDXy+aCB3jCB26SB2DCB1TELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJh
# dGlvbnMgUHVlcnRvIFJpY28xJzAlBgNVBAsTHm5DaXBoZXIgTlRTIEVTTjo0REU5
# LTBDNUUtM0UwOTErMCkGA1UEAxMiTWljcm9zb2Z0IFRpbWUgU291cmNlIE1hc3Rl
# ciBDbG9jazANBgkqhkiG9w0BAQUFAAIFAOFZ0S4wIhgPMjAxOTEwMjMwMzA0MTRa
# GA8yMDE5MTAyNDAzMDQxNFowdjA8BgorBgEEAYRZCgQBMS4wLDAKAgUA4VnRLgIB
# ADAJAgEAAgE1AgH/MAcCAQACAhgMMAoCBQDhWyKuAgEAMDYGCisGAQQBhFkKBAIx
# KDAmMAwGCisGAQQBhFkKAwGgCjAIAgEAAgMHoSChCjAIAgEAAgMHoSAwDQYJKoZI
# hvcNAQEFBQADggEBAH9sFGpAAKP8+TLLmQBbp6zYu5qS7nUU1hE2j7BdirzAjzrb
# L8WK1w2y6K58rfw5C81d0L7zJkaSh4bimE5wiGSAbM8qWOkM26CoI/BXtjN2MskQ
# hDmxgb1p7vBt170S0q/wCJLhqdDROugCwWZoSnRJB7JMA9uP44Jgjb0AEADD3+Ed
# g5I38Gh4DIjYzA0W1STpQnSxHF6oSKzwDAR+uPQfUeXpRfVI040T7QNxiNXYgxzI
# iIe0uZcl0yznJnbAZwWkqhgjy3ql1b3MtWomwmZHtDXxfwX1jSnFXGZayuuJ5s76
# 0y+yrCpZJ73N++ywod/vuq/oRiKzddwSIvIY5tMxggL1MIIC8QIBATCBkzB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAQZhtUSZ+Ory7QAAAAABBjAN
# BglghkgBZQMEAgEFAKCCATIwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8G
# CSqGSIb3DQEJBDEiBCBeQFf2hhXzsJmnCNy9IDQlIw4WEvLFYiVABUq/IFHivzCB
# 4gYLKoZIhvcNAQkQAgwxgdIwgc8wgcwwgbEEFGO9+BoeVYVq7hbxu+WwvM9UNfL5
# MIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAEGYbVE
# mfjq8u0AAAAAAQYwFgQUJgb9Px0g5G6FopgE0OU1RZTKKCIwDQYJKoZIhvcNAQEL
# BQAEggEAIjw1YLIHC0ZaeEeqoNU0mqKka6AxTROTVlXUY6TWK1gXyxvb/h9UQYGO
# 50I4MB2/Dwn4jT7ulrNMWMSf/le65EP+G9UcphnTWnUzHiLs2/4TgzFpTa9//nMa
# Gv5aWkBye7owmZQeua8rV+TWuQDi0JSjZtShNk5eIsMr61lqHNzwnWmvgjPPJvIK
# v3Lqf/1b1rmf9tLTL/crYq/Fz/gGZwhmMLFfexZReX96uwdOACf3D5Xlu+AZPbf7
# 2crY5xj0eYYFsNi1zuPwMPJVaLSCgHGyjmdWAoHesPC0a/U+pfI86KsdY9p5HrmB
# s0xgFtELCKskqgyPMj09Gc4Vhh4yVw==
# SIG # End signature block
