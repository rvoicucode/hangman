﻿
$blackListedPackage = (
"dynamicsax-appfoundationtestcommon",
"dynamicsax-appfoundationtestcommon-compile",
"dynamicsax-appfoundationtestcommon-develop",
"dynamicsax-appfoundationtestcommon-formadaptor",
"dynamicsax-application-applicationruntime",
"dynamicsax-applicationfoundation-compile",
"dynamicsax-applicationfoundation-develop",
"dynamicsax-applicationfoundation-formadaptor",
"dynamicsax-applicationfoundationformadaptor-compile",
"dynamicsax-applicationfoundationformadaptor-develop",
"dynamicsax-applicationfoundationformadaptor-formadaptor",
"dynamicsax-applicationfoundationunittests",
"dynamicsax-applicationfoundationunittests-compile",
"dynamicsax-applicationfoundationunittests-develop",
"dynamicsax-applicationfoundationunittests-formadaptor",
"dynamicsax-applicationplatform-compile",
"dynamicsax-applicationplatform-develop",
"dynamicsax-applicationplatform-formadaptor",
"dynamicsax-applicationplatformformadaptor-compile",
"dynamicsax-applicationplatformformadaptor-develop",
"dynamicsax-applicationplatformformadaptor-formadaptor",
"dynamicsax-applicationstaging",
"dynamicsax-applicationstaging-compile",
"dynamicsax-applicationstaging-develop",
"dynamicsax-applicationstagingformadaptor",
"dynamicsax-applicationstaging-formadaptor",
"dynamicsax-applicationstagingformadaptor-compile",
"dynamicsax-applicationstagingformadaptor-develop",
"dynamicsax-applicationstagingformadaptor-formadaptor",
"dynamicsax-applicationstagingtests",
"dynamicsax-applicationstagingtests-compile",
"dynamicsax-applicationstagingtests-develop",
"dynamicsax-applicationstagingtests-formadaptor",
"dynamicsax-applicationsuite-compile",
"dynamicsax-applicationsuite-develop",
"dynamicsax-applicationsuite-formadaptor",
"dynamicsax-applicationsuiteformadaptor-compile",
"dynamicsax-applicationsuiteformadaptor-develop",
"dynamicsax-applicationsuiteformadaptor-formadaptor",
"dynamicsax-applicationworkspaces-compile",
"dynamicsax-applicationworkspaces-develop",
"dynamicsax-applicationworkspacesformadaptor",
"dynamicsax-applicationworkspaces-formadaptor",
"dynamicsax-applicationworkspacesformadaptor-compile",
"dynamicsax-applicationworkspacesformadaptor-develop",
"dynamicsax-applicationworkspacesformadaptor-formadaptor",
"dynamicsax-applicationworkspacestests",
"dynamicsax-applicationworkspacestests-compile",
"dynamicsax-applicationworkspacestests-develop",
"dynamicsax-applicationworkspacestests-formadaptor",
"dynamicsax-appplatformtestcommon",
"dynamicsax-appplatformtestcommon-compile",
"dynamicsax-appplatformtestcommon-develop",
"dynamicsax-appplatformtestcommon-formadaptor",
"dynamicsax-appsuitetestcommon",
"dynamicsax-appsuitetestcommon-compile",
"dynamicsax-appsuitetestcommon-develop",
"dynamicsax-appsuitetestcommon-formadaptor",
"dynamicsax-budgetstaging",
"dynamicsax-budgetstaging-compile",
"dynamicsax-budgetstaging-develop",
"dynamicsax-budgetstagingformadaptor",
"dynamicsax-budgetstaging-formadaptor",
"dynamicsax-budgetstagingformadaptor-compile",
"dynamicsax-budgetstagingformadaptor-develop",
"dynamicsax-budgetstagingformadaptor-formadaptor",
"dynamicsax-budgetstagingtests",
"dynamicsax-budgetstagingtests-compile",
"dynamicsax-budgetstagingtests-develop",
"dynamicsax-budgetstagingtests-formadaptor",
"dynamicsax-calendar-compile",
"dynamicsax-calendar-develop",
"dynamicsax-calendarformadaptor",
"dynamicsax-calendar-formadaptor",
"dynamicsax-calendarformadaptor-compile",
"dynamicsax-calendarformadaptor-develop",
"dynamicsax-calendarformadaptor-formadaptor",
"dynamicsax-calendartests",
"dynamicsax-calendartests-compile",
"dynamicsax-calendartests-develop",
"dynamicsax-calendartests-formadaptor",
"dynamicsax-cirfoundationtests",
"dynamicsax-cirfoundationtests-compile",
"dynamicsax-cirfoundationtests-develop",
"dynamicsax-cirfoundationtests-formadaptor",
"dynamicsax-costaccounting",
"dynamicsax-costaccounting-compile",
"dynamicsax-costaccounting-develop",
"dynamicsax-costaccounting-formadaptor",
"dynamicsax-costaccountingformadaptor",
"dynamicsax-costaccountingformadaptor-compile",
"dynamicsax-costaccountingformadaptor-develop",
"dynamicsax-costaccountingformadaptor-formadaptor",
"dynamicsax-costaccountingtests",
"dynamicsax-costaccountingtests-compile",
"dynamicsax-costaccountingtests-develop",
"dynamicsax-costaccountingtests-formadaptor",
"dynamicsax-costaccountingax",
"dynamicsax-costaccountingax-compile",
"dynamicsax-costaccountingax-develop",
"dynamicsax-costaccountingax-formadaptor",
"dynamicsax-costaccountingaxformadaptor",
"dynamicsax-costaccountingaxformadaptor-compile",
"dynamicsax-costaccountingaxformadaptor-develop",
"dynamicsax-costaccountingaxformadaptor-formadaptor",
"dynamicsax-costaccountingaxtests",
"dynamicsax-costaccountingaxtests-compile",
"dynamicsax-costaccountingaxtests-develop",
"dynamicsax-costaccountingaxtests-formadaptor",
"dynamicsax-currency-compile",
"dynamicsax-currency-develop",
"dynamicsax-currencyformadaptor",
"dynamicsax-currency-formadaptor",
"dynamicsax-currencyformadaptor-compile",
"dynamicsax-currencyformadaptor-develop",
"dynamicsax-currencyformadaptor-formadaptor",
"dynamicsax-customeracceptancetests-compile",
"dynamicsax-customeracceptancetests-develop",
"dynamicsax-customeracceptancetests-formadaptor",
"dynamicsax-data-contoso",
"dynamicsax-data-demodata",
"dynamicsax-data-demovolumedata",
"dynamicsax-data-empty",
"dynamicsax-data-empty-platform",
"dynamicsax-dataimpexpapplication-compile",
"dynamicsax-dataimpexpapplication-develop",
"dynamicsax-dataimpexpapplication-formadaptor",
"dynamicsax-demodatasuite",
"dynamicsax-demodatasuite-compile",
"dynamicsax-demodatasuite-develop",
"dynamicsax-demodatasuite-formadaptor",
"dynamicsax-devtoolscustomizations",
"dynamicsax-devtoolscustomizations2",
"dynamicsax-devtoolscustomizations2-compile",
"dynamicsax-devtoolscustomizations2-develop",
"dynamicsax-devtoolscustomizations2-formadaptor",
"dynamicsax-devtoolscustomizations-compile",
"dynamicsax-devtoolscustomizations-develop",
"dynamicsax-devtoolscustomizations-formadaptor",
"dynamicsax-devtoolstestmodel",
"dynamicsax-devtoolstestmodel2",
"dynamicsax-devtoolstestmodel2-compile",
"dynamicsax-devtoolstestmodel2-develop",
"dynamicsax-devtoolstestmodel2-formadaptor",
"dynamicsax-devtoolstestmodel-compile",
"dynamicsax-devtoolstestmodel-develop",
"dynamicsax-devtoolstestmodel-formadaptor",
"dynamicsax-dimensions-compile",
"dynamicsax-dimensions-develop",
"dynamicsax-dimensionsformadaptor",
"dynamicsax-dimensions-formadaptor",
"dynamicsax-dimensionsformadaptor-compile",
"dynamicsax-dimensionsformadaptor-develop",
"dynamicsax-dimensionsformadaptor-formadaptor",
"dynamicsax-dimensionstestcommon",
"dynamicsax-dimensionstestcommon-compile",
"dynamicsax-dimensionstestcommon-develop",
"dynamicsax-dimensionstestcommon-formadaptor",
"dynamicsax-dimensionstests",
"dynamicsax-dimensionstests-compile",
"dynamicsax-dimensionstests-develop",
"dynamicsax-dimensionstests-formadaptor",
"dynamicsax-directory-compile",
"dynamicsax-directory-develop",
"dynamicsax-directory-formadaptor",
"dynamicsax-directoryformadaptor-compile",
"dynamicsax-directoryformadaptor-develop",
"dynamicsax-directoryformadaptor-formadaptor",
"dynamicsax-directorytests",
"dynamicsax-directorytests-compile",
"dynamicsax-directorytests-develop",
"dynamicsax-directorytests-formadaptor",
"dynamicsax-dispatchservice",
"dynamicsax-electronicreporting-compile",
"dynamicsax-electronicreporting-develop",
"dynamicsax-electronicreporting-formadaptor",
"dynamicsax-electronicreportingtestcommon",
"dynamicsax-electronicreportingtestcommon-compile",
"dynamicsax-electronicreportingtestcommon-develop",
"dynamicsax-electronicreportingtestcommon-formadaptor",
"dynamicsax-electronicreportingtests",
"dynamicsax-electronicreportingtests-compile",
"dynamicsax-electronicreportingtests-develop",
"dynamicsax-electronicreportingtests-formadaptor",
"dynamicsax-financialaccountingworkload",
"dynamicsax-financialaccountingworkload-compile",
"dynamicsax-financialaccountingworkload-develop",
"dynamicsax-financialaccountingworkload-formadaptor",
"dynamicsax-financialaccounting",
"dynamicsax-financialaccounting-compile",
"dynamicsax-financialaccounting-develop",
"dynamicsax-financialaccounting-formadaptor",
"dynamicsax-financialreportingadaptors",
"dynamicsax-financialreportingadaptors-compile",
"dynamicsax-financialreportingadaptors-develop",
"dynamicsax-financialreportingadaptors-formadaptor",
"dynamicsax-financialreporting-compile",
"dynamicsax-financialreporting-develop",
"dynamicsax-financialreporting-formadaptor",
"dynamicsax-financialreportingtestcommon",
"dynamicsax-financialreportingtestcommon-compile",
"dynamicsax-financialreportingtestcommon-develop",
"dynamicsax-financialreportingtestcommon-formadaptor",
"dynamicsax-financialreportingtests",
"dynamicsax-financialreportingtests-compile",
"dynamicsax-financialreportingtests-develop",
"dynamicsax-financialreportingtests-formadaptor",
"dynamicsax-fiscalbooks-compile",
"dynamicsax-fiscalbooks-develop",
"dynamicsax-fiscalbooksformadaptor",
"dynamicsax-fiscalbooks-formadaptor",
"dynamicsax-fiscalbooksformadaptor-compile",
"dynamicsax-fiscalbooksformadaptor-develop",
"dynamicsax-fiscalbooksformadaptor-formadaptor",
"dynamicsax-fiscalbookstests",
"dynamicsax-fiscalbookstests-compile",
"dynamicsax-fiscalbookstests-develop",
"dynamicsax-fiscalbookstests-formadaptor",
"dynamicsax-fleetmanagement-compile",
"dynamicsax-fleetmanagement-develop",
"dynamicsax-fleetmanagementextension-compile",
"dynamicsax-fleetmanagementextension-develop",
"dynamicsax-fleetmanagementextension-formadaptor",
"dynamicsax-fleetmanagement-formadaptor",
"dynamicsax-fleetmanagementunittests-compile",
"dynamicsax-fleetmanagementunittests-develop",
"dynamicsax-fleetmanagementunittests-formadaptor",
"dynamicsax-foundationtest",
"dynamicsax-foundationtestcommon",
"dynamicsax-foundationtestcommon-compile",
"dynamicsax-foundationtestcommon-develop",
"dynamicsax-foundationtestcommon-formadaptor",
"dynamicsax-foundationtest-compile",
"dynamicsax-foundationtest-develop",
"dynamicsax-foundationtest-formadaptor",
"dynamicsax-generalledger-compile",
"dynamicsax-generalledger-develop",
"dynamicsax-generalledgerformadaptor",
"dynamicsax-generalledger-formadaptor",
"dynamicsax-generalledgerformadaptor-compile",
"dynamicsax-generalledgerformadaptor-develop",
"dynamicsax-generalledgerformadaptor-formadaptor",
"dynamicsax-generalledgertests",
"dynamicsax-generalledgertests-compile",
"dynamicsax-generalledgertests-develop",
"dynamicsax-generalledgertests-formadaptor",
"dynamicsax-gfmtests",
"dynamicsax-gfmtests-compile",
"dynamicsax-gfmtests-develop",
"dynamicsax-gfmtests-formadaptor",
"dynamicsax-hcmtests",
"dynamicsax-hcmtests-compile",
"dynamicsax-hcmtests-develop",
"dynamicsax-hcmtests-formadaptor",
"dynamicsax-ledger-compile",
"dynamicsax-ledger-develop",
"dynamicsax-ledger-formadaptor",
"dynamicsax-ledgerformadaptor-compile",
"dynamicsax-ledgerformadaptor-develop",
"dynamicsax-ledgerformadaptor-formadaptor",
"dynamicsax-ledgertests",
"dynamicsax-ledgertests-compile",
"dynamicsax-ledgertests-develop",
"dynamicsax-ledgertests-formadaptor",
"dynamicsax-measurement-compile",
"dynamicsax-measurement-develop",
"dynamicsax-measurementformadaptor",
"dynamicsax-measurement-formadaptor",
"dynamicsax-measurementformadaptor-compile",
"dynamicsax-measurementformadaptor-develop",
"dynamicsax-measurementformadaptor-formadaptor",
"dynamicsax-measurementtests",
"dynamicsax-measurementtests-compile",
"dynamicsax-measurementtests-develop",
"dynamicsax-measurementtests-formadaptor",
"dynamicsax-meta-application-development",
"dynamicsax-meta-application-runtime",
"dynamicsax-meta-businessappplatform-development",
"dynamicsax-meta-businessappplatform-runtime",
"dynamicsax-meta-financialaccounting-development",
"dynamicsax-meta-financialaccounting-runtime",
"dynamicsax-meta-onebox-app-development",
"dynamicsax-meta-onebox-app-runtime",
"dynamicsax-meta-onebox-financialaccounting-development",
"dynamicsax-meta-onebox-financialaccounting-runtime",
"dynamicsax-meta-onebox-platform-development",
"dynamicsax-meta-onebox-platform-runtime",
"dynamicsax-meta-platform-development",
"dynamicsax-meta-platform-runtime",
"dynamicsax-OrchestrationPlugins",
"dynamicsax-organization-compile",
"dynamicsax-organization-develop",
"dynamicsax-organizationformadaptor",
"dynamicsax-organization-formadaptor",
"dynamicsax-organizationformadaptor-compile",
"dynamicsax-organizationformadaptor-develop",
"dynamicsax-organizationformadaptor-formadaptor",
"dynamicsax-organizationtests",
"dynamicsax-organizationtests-compile",
"dynamicsax-organizationtests-develop",
"dynamicsax-organizationtests-formadaptor",
"dynamicsax-payroll-compile",
"dynamicsax-payroll-develop",
"dynamicsax-payrollformadaptor",
"dynamicsax-payroll-formadaptor",
"dynamicsax-payrollformadaptor-compile",
"dynamicsax-payrollformadaptor-develop",
"dynamicsax-payrollformadaptor-formadaptor",
"dynamicsax-payrolltests",
"dynamicsax-payrolltests-compile",
"dynamicsax-payrolltests-develop",
"dynamicsax-payrolltests-formadaptor",
"dynamicsax-performancetest",
"dynamicsax-performancetest-compile",
"dynamicsax-performancetest-develop",
"dynamicsax-performancetest-formadaptor",
"dynamicsax-performancetool",
"dynamicsax-performancetool-compile",
"dynamicsax-performancetool-develop",
"dynamicsax-performancetool-formadaptor",
"dynamicsax-performancetoolunittests",
"dynamicsax-performancetoolunittests-compile",
"dynamicsax-performancetoolunittests-develop",
"dynamicsax-performancetoolunittests-formadaptor",
"dynamicsax-policy-compile",
"dynamicsax-policy-develop",
"dynamicsax-policyformadaptor",
"dynamicsax-policy-formadaptor",
"dynamicsax-policyformadaptor-compile",
"dynamicsax-policyformadaptor-develop",
"dynamicsax-policyformadaptor-formadaptor",
"dynamicsax-policytests",
"dynamicsax-policytests-compile",
"dynamicsax-policytests-develop",
"dynamicsax-policytests-formadaptor",
"dynamicsax-primitivetest",
"dynamicsax-primitivetest-compile",
"dynamicsax-primitivetest-develop",
"dynamicsax-primitivetest-formadaptor",
"dynamicsax-productconfiguration",
"dynamicsax-publicsector-compile",
"dynamicsax-publicsector-develop",
"dynamicsax-publicsectorformadaptor",
"dynamicsax-publicsector-formadaptor",
"dynamicsax-publicsectorformadaptor-compile",
"dynamicsax-publicsectorformadaptor-develop",
"dynamicsax-publicsectorformadaptor-formadaptor",
"dynamicsax-publicsectortests",
"dynamicsax-publicsectortests-compile",
"dynamicsax-publicsectortests-develop",
"dynamicsax-publicsectortests-formadaptor",
"dynamicsax-retailtests",
"dynamicsax-retailtests-compile",
"dynamicsax-retailtests-develop",
"dynamicsax-retailtests-formadaptor",
"dynamicsax-scmtests",
"dynamicsax-scmtests-compile",
"dynamicsax-scmtests-develop",
"dynamicsax-scmtests-formadaptor",
"dynamicsax-scmteststaging",
"dynamicsax-scmteststaging-compile",
"dynamicsax-scmteststaging-develop",
"dynamicsax-scmteststaging-formadaptor",
"dynamicsax-servertests",
"dynamicsax-servertests-compile",
"dynamicsax-servertests-develop",
"dynamicsax-servertests-formadaptor",
"dynamicsax-sitests",
"dynamicsax-sitests-compile",
"dynamicsax-sitests-develop",
"dynamicsax-sitests-formadaptor",
"dynamicsax-sourcedocumentation-compile",
"dynamicsax-sourcedocumentation-develop",
"dynamicsax-sourcedocumentationformadaptor",
"dynamicsax-sourcedocumentation-formadaptor",
"dynamicsax-sourcedocumentationformadaptor-compile",
"dynamicsax-sourcedocumentationformadaptor-develop",
"dynamicsax-sourcedocumentationformadaptor-formadaptor",
"dynamicsax-sourcedocumentationtypes-compile",
"dynamicsax-sourcedocumentationtypes-develop",
"dynamicsax-sourcedocumentationtypes-formadaptor",
"dynamicsax-sourcedocumentationtests",
"dynamicsax-sourcedocumentationtests-compile",
"dynamicsax-sourcedocumentationtests-develop",
"dynamicsax-sourcedocumentationtests-formadaptor",
"dynamicsax-subledger-compile",
"dynamicsax-subledger-develop",
"dynamicsax-subledgerformadaptor",
"dynamicsax-subledger-formadaptor",
"dynamicsax-subledgerformadaptor-compile",
"dynamicsax-subledgerformadaptor-develop",
"dynamicsax-subledgerformadaptor-formadaptor",
"dynamicsax-sysfake",
"dynamicsax-sysfake-compile",
"dynamicsax-sysfake-develop",
"dynamicsax-sysfake-formadaptor",
"dynamicsax-tax-compile",
"dynamicsax-tax-develop",
"dynamicsax-taxformadaptor",
"dynamicsax-tax-formadaptor",
"dynamicsax-taxformadaptor-compile",
"dynamicsax-taxformadaptor-develop",
"dynamicsax-taxformadaptor-formadaptor",
"dynamicsax-test",
"dynamicsax-test-compile",
"dynamicsax-test-develop",
"dynamicsax-testessentials-compile",
"dynamicsax-testessentials-develop",
"dynamicsax-testessentials-formadaptor",
"dynamicsax-test-formadaptor",
"dynamicsax-tutorial-compile",
"dynamicsax-tutorial-develop",
"dynamicsax-tutorial-formadaptor",
"dynamicsax-unitofmeasure-compile",
"dynamicsax-unitofmeasure-develop",
"dynamicsax-unitofmeasure-formadaptor",
"dynamicsax-unitofmeasureformadaptor-compile",
"dynamicsax-unitofmeasureformadaptor-develop",
"dynamicsax-unitofmeasureformadaptor-formadaptor",
"dynamicsax-unittests",
"dynamicsax-unittests-compile",
"dynamicsax-unittests-develop",
"dynamicsax-unittests-formadaptor",
"dynamicsax-upgrade",
"dynamicsax-upgrade-compile",
"dynamicsax-upgrade-develop",
"dynamicsax-upgrade-formadaptor")

$sourcePath = [IO.Path]::Combine($(split-Path -parent $PSScriptRoot), "Packages")
$files=get-childitem -Path:$sourcePath *.nupkg
foreach ($file in $files) 
{
    $fileName =  ($file.BaseName).Split(".")[0]
    if ($blackListedPackage -contains "$fileName")
    {
        write-output "Removing $file from packaging folder"
        remove-item $file.FullName
    }
}

# SIG # Begin signature block
# MIIkvgYJKoZIhvcNAQcCoIIkrzCCJKsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBQ/MgBoh93T74S
# oGaMvj2lmJHriRwzOBJxd3oxs0OkKKCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWkzCCFo8CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB+TAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQghhR44ZU8
# G6x0ga/zIaKmtCpki/LUpSEOW+RAtZDve+4wgYwGCisGAQQBgjcCAQwxfjB8oF6A
# XABBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBlAHIA
# dgBpAGMAZQBQAGwAYQB0AGYAbwByAG0AVQBwAGQAYQB0AGUAMQAuAHAAcwAxoRqA
# GGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQBbMsO+
# Wm+ntTFJxPXfptTkmgXcsOSxNUIWL/jYpBti4NNPOmLY2O2k/8eTjtuL0FNEjnoI
# YxwTpfQ6LW5YYRX2vq2I2qes2Qh8uzl7els41KWTvzvBnP/Ydpg1kjNUGXYmMwJ9
# LH0a+jWJtpVoZhi1LmZrD7gxUTtpTG7oVHpGWTRfOmuZG4aE9QsVxqFOvAcOKvUE
# zvF4ZMaHdOKhmuF1CcDIYu3CBhvYOI4GXawMBrTMvxMsIGLEGL5q18C0wXxKSfET
# W/IfYbl9TDkullUs7raDCUMFswPTLJo93MRU+zXAPhZtUtuUfhr9/4SfKUdxO6EZ
# 1cY3TI4n2cUVmjmNoYIT0jCCE84GCisGAQQBgjcDAwExghO+MIITugYJKoZIhvcN
# AQcCoIITqzCCE6cCAQMxDzANBglghkgBZQMEAgEFADCCAVgGCyqGSIb3DQEJEAEE
# oIIBRwSCAUMwggE/AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIONA
# Ov7ROBOI5RrhV10hOR6ngwr1ulnCe48tr2xuhZuPAgZdiMrMH44YEzIwMTkxMDIz
# MDY1OTQ4LjU0N1owBwIBAYACAfSggdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25z
# IFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo5OEZELUM2MUUt
# RTY0MTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCDyIw
# ggT1MIID3aADAgECAhMzAAAA++CUDxRBhNvFAAAAAAD7MA0GCSqGSIb3DQEBCwUA
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE5MDkwNjIwNDEwNloX
# DTIwMTIwNDIwNDEwNlowgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNv
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo5OEZELUM2MUUtRTY0MTElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAKAhY+5J8HXlmAVU+70WH7Tm4GcoAWQzzKyzLYgQjL+m
# ViTGe5p0zbwF49ZJcdXgwQkDM/uA2j8xj0ory2Uh5CefDW/AUHz9R2qkIe5Abjbj
# LADgCKg6U3SAlWfz8NoKNE8xu2Uy/8zpLDcVc0jw4B36Kq6Yjm8xXcsyxjObbaVz
# Iicl23bsuJgkkCD1sathSBFrwDVEYQHk8R1YwgFE8NB/ngp+4P02rAmuNpcc1wBO
# yvTyEbS8l1mirMFhT9VbDftN6s1zd0Mlp+Hrp5U0NGPwS+mEHilvjabY67LBK3BZ
# LYgmUcitV46XontBCBv9K+5oPtpRrdbPVu2ge2THNecCAwEAAaOCARswggEXMB0G
# A1UdDgQWBBSQPADvO9LEi5oW6lyRMkqJD6tNjDAfBgNVHSMEGDAWgBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNy
# dDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# CwUAA4IBAQBD2sGnRfoXWNGCeqAhw+SMyp8zSS7zFkOoGnH8IQtXLY2wMezdaD3O
# 8NVB2+1J4jfygw7XiBkFQt40i+85x8ig+oUnZl1F+f3l6TKbCLIeAlpvfRT2USLH
# O+4PIUX9wYViqOF7FXlP2DJC/1ga/bGhF5mcKxlcPo4BWk8cuO3BCjXabNCs5oHb
# NHVfxUI9xVKYUBN3GNDl+72j50bE11Jg8ZgVwI2Syw1j7UiC7ZHYzZ7GCNyuH3z9
# qGIXWgr6Nb/il5pPfsOWRI1bQbL0/oc/Q4TP9tqhvCi57T+59NYz+33KAGx0SghL
# Bcg6grUKyI6cgNf+fOUb/FQR+8Ph2SAyMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAA
# AjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0
# aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPl
# YcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2T
# rNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFh
# E24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+c
# Bj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn
# 9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQB
# gjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB
# /zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEE
# AYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9Q
# S0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcA
# YQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZI
# hvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20Z
# MLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX
# /1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+TH
# zvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnx
# zplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjY
# lPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kW
# umGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3
# ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slva
# yA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5
# KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czm
# TfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYID
# sDCCApgCAQEwgf6hgdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBS
# aWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo5OEZELUM2MUUtRTY0MTElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIlCgEBMAkGBSsOAwIa
# BQADFQAV9O+PCUZ4KHTCMuuXBK/6zr9CMaCB3jCB26SB2DCB1TELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJzAlBgNVBAsTHm5DaXBoZXIgTlRTIEVTTjo0
# REU5LTBDNUUtM0UwOTErMCkGA1UEAxMiTWljcm9zb2Z0IFRpbWUgU291cmNlIE1h
# c3RlciBDbG9jazANBgkqhkiG9w0BAQUFAAIFAOFaXAYwIhgPMjAxOTEwMjMxMjU2
# MzhaGA8yMDE5MTAyNDEyNTYzOFowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA4Vpc
# BgIBADAKAgEAAgICvgIB/zAHAgEAAgIZ7zAKAgUA4VuthgIBADA2BgorBgEEAYRZ
# CgQCMSgwJjAMBgorBgEEAYRZCgMBoAowCAIBAAIDFuNgoQowCAIBAAIDB6EgMA0G
# CSqGSIb3DQEBBQUAA4IBAQBI7jHE+pChkg69b6CkS0PLhIKSnX6XYOXcnL+ZslW/
# 7lpop3/I/AFSGgtJEvJvtKDRWFm1H8+JsE4JcLAypwJJAHud03A1LPFmoMY3H6+U
# MbTAo8m+aVWD3qwZc7P2fdZhr45m9RxBxstWIFaGXdw8nvV80JVYeSUyy2EKXswv
# Z51gc0y+ySGtzAeAaCwr0XPb2orW+xJrxwMtK+Otpw8zLZ2/b8gHwC6zAhuLgt5M
# YgsSCKhSGcFqUzG/wr1mf2WQyencr0CwPba6lMA80AGPKPx4ToWtZ5w2Qa6R+TqQ
# 4OgrDaTi4/iq1FgfNUh7D+16Y5Y6U87Gf7WI1Pf7Xr+4MYIDDTCCAwkCAQEwgZMw
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAD74JQPFEGE28UAAAAA
# APswDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRAB
# BDAvBgkqhkiG9w0BCQQxIgQgLPxIIjyfJrXgMg26VxpnvS/FfAZKo9xx+rAcctfG
# qLkwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCBu8fQjDOJ6yHyR/w+/uqCS
# cFrrBeJLrXDO9BpMK7r+3TCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAAA++CUDxRBhNvFAAAAAAD7MCIEIHKZ6OYl/z3T11Rw3dUya2hs
# LfZWLjmm5jorT7H0GJuHMA0GCSqGSIb3DQEBCwUABIIBAD4xFOmgelh6M8izUcuM
# JDxRn2aICcyoropJw4hf91ydmxTl3s1pxqW/cb51+excDTgQyfgJ3Z4XssScvQld
# Y20slpEtTjTwt/F3idADUKEcISzY9GOauPo7isipXEwUGqQkDeQMUYwRIikRgz3p
# VqgNpO7KO7/7B5amTPHrfgqzNjL7jrGrgKCAtsQQ7hjGSC+39Lq+eLm7Eku6G32E
# oXvC2kjr3k0rjL/CUZI2YwjeV1tx7L1gv7KZ11YPRYG1Y9ZVPyTDiLOFVUxP4gc2
# UPHYGnYF/NKDVUaGRl5rVacrsat0T+Oq+2buWZlrE++HuBrZ3Ks/fWjYrkCbGezA
# ph0=
# SIG # End signature block
