<#
.Synopsis
   Installs Management Reporter
.DESCRIPTION
   Installs Management Reporter to $InstallLocation using the MSI specified either by MsiPath or local to this script.
#>
[CmdletBinding()]
Param
(
	# Log file set from Deployment task.
	[string]
	$log,

	# JSON encoded dictionary containing configuration settings from Deployment task.
	[string]
	$config,

	# Used by DSC, actual XML file in base64 form. Use if cert data/info is needed.
	[string]
	$serviceModelXml,

	# On fileshare script's location is used, on OneBox $env:dplLogDir is used.
	[string]
	$LogPath = "$PSScriptRoot",

	# Indicates to not install or remove MSI.
	[switch]
	$NoInstall,

	# Path to directory containing MSI and CAB file for MR server. Supports shortcut (.lnk) files. This path is used if the MSI is not next to this script file.
	[string]
	$MsiPath = '\\cpmint-file01\builds\mr\AX7_Build.lnk',

	# Indicates to force the -MsiPath to be used.
	[switch]
	$ForceMsiPath,

	# Indicates to force a non-recursive search for the MSI file.
	[switch]
	$ForceNonRecursiveFind,

	# Indicates to suppresses any warnings that would show from -Remove.
	[switch]
	$SuppressWarning,

	# Path to install MSI to, this overrides the default settings of the MSI. Default is c:\FinancialReporting.
	[string]
	$InstallLocation = 'c:\FinancialReporting',

	# Indicates this is an upgrade vs. a clean install
	[switch]
	$Upgrade
)

. "$PSScriptRoot\ScriptSetup.ps1"
Set-LogPath -FullLogPath $log -LogDir $LogPath
if ($log -and !$LogPath)
{
	$LogPath = [System.IO.Path]::GetDirectoryName($log)
}

Write-EnvironmentDataToLog
$Settings = Get-SettingsObject -Config $config -ServiceModelXml $serviceModelXml

function Install-Msi
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Position = 0)]
		[string]
		[ValidateNotNullOrEmpty()]
		$PackagePath,

		[Parameter(ParameterSetName = 'Install')]
		[switch]
		$Install,

		[Parameter(ParameterSetName = 'AdministratorInstall')]
		[switch]
		$AdminInstall,

		[Parameter(ParameterSetName = 'Uninstall')]
		[switch]
		$Uninstall,

		[Parameter(ParameterSetName = 'Repair')]
		[switch]
		$Repair,

		[switch]
		$Quiet,

		[switch]
		$Passive,

		[switch]
		$NoRestart,

		[switch]
		$PromptRestart,

		[switch]
		$ForceRestart,

		[switch]
		$Log,

		[string]
		$LogName,

		[string]
		[ValidateNotNullOrEmpty()]
		$LogDirectory = '.',

		[Hashtable]
		$Properties
	)

	if(!(Test-Path $PackagePath))
	{
		throw "$PackagePath was an invalid MSI package path"
	}

	[string[]]$commands = @()
	
	if($Install) 
	{
		$commands += '/i' 
	}
	elseif($AdminInstall) 
	{
		$commands += '/a' 
	}
	elseif($Uninstall) 
	{
		$commands += '/x' 
	}
	elseif($Repair)
	{
		$commands += '/fp' 
	}

	$PackagePath = $PackagePath.Trim('"').Trim() # remove start and ending double-quotes and any trailing whitespace
	$commands += "`"$PackagePath`""

	if($Quiet) 
	{
		$commands += '/quiet' 
	}
	if($Passive) 
	{
		$commands += '/passive' 
	}
	if($NoRestart) 
	{
		$commands += '/norestart' 
	}
	if($PromptRestart) 
	{
		$commands += '/promptrestart' 
	}
	if($ForceRestart) 
	{
		$commands += '/forcerestart' 
	}

	if($Log)
	{
		if(!$LogName)
		{
			$LogName = Join-Path -Path (Resolve-Path $LogDirectory).Path -ChildPath "$([System.IO.Path]::GetFileNameWithoutExtension($PackagePath))_$(Get-Date -Format yyyyMMdd-HHmmss).log"
		}
		else
		{
			$LogName = $LogName.Trim('"').Trim()
		}

		Write-LogMessage -Message "MSI log will be available at $LogName"

		$commands += '/log'
		$commands += "`"$LogName`""
	}

	if($Properties)
	{
		foreach($property in $Properties.GetEnumerator())
		{
			$commands += "$($property.Key.ToString().Trim().ToUpperInvariant())=`"$($property.Value.ToString().Trim())`""
		}
	}

	$execute = 'msiexec.exe ' + [string]::Join(' ', $commands)
	Write-Debug -Message $execute
	$p = Start-Process -FilePath msiexec.exe -Wait -ArgumentList $commands -PassThru
	if($p.ExitCode -ne 0)
	{
		$logFileMessage = 'specify -Log to Install-Msi for capturing log'
		if($Log)
		{
			$logFileMessage = "log available at $LogName"
		}

		throw "MSIEXEC exited with error code $($p.ExitCode), $logFileMessage"
	}

	Write-LogMessage -Message "[Success] Executing $execute"
}

function Find-MRInstaller
{
	[CmdletBinding()]
	Param
	(
		# Param1 help description
		[Parameter(ValueFromPipeline = $true, Position = 0)]
		[string]
		$MsiDirectoryPath,

		[Parameter(ParameterSetName = 'Server')]
		[switch]
		$Server,

		[Parameter(ParameterSetName = 'Client')]
		[switch]
		$Client,

		[switch]
		$RecursiveFind,

		[switch]
		$ForceMsiDirectoryPath
	)

	# If not using recursive find, no point adding PSScriptRoot because it is always a directory
	if(!$RecursiveFind -or $ForceMsiDirectoryPath)
	{
		 $possibleLocations = @($MsiDirectoryPath)
	}
	else
	{
		 $possibleLocations = @($PSScriptRoot, $MsiDirectoryPath)
	}
   
	[string] $msiName = ''
	if($Server)
	{
		$msiName = Get-MRInstallerName -Server
	}
	else
	{
		$msiName = Get-MRInstallerName -Client
	}

	foreach($location in $possibleLocations)
	{
		# because PSScriptRoot will always be valid, it's safe to say the issue is MsiDirectoryPath
		if([string]::IsNullOrEmpty($location))
		{
			throw "Empty or null path specified for -MsiDirectoryPath, $location"
		}

		if(!(Test-Path $location))
		{
			throw "Invalid path supplied for -MsiDirectoryPath, $location"
		}

		if($location.EndsWith('.lnk'))
		{
			$shell = New-Object -ComObject WScript.Shell
			$location = Get-ChildItem -Path $location -Filter *.lnk |
				ForEach-Object -Process {
					$shell.CreateShortcut($_.FullName).TargetPath 
				} |
				Select-Object -First 1
			
			if(!(Test-Path $location))
			{
				throw "Invalid path specified in shortcut for -MsiDirectoryPath, $MsiDirectoryPath"
			}
		}

		if($RecursiveFind)
		{
			$msiFilePath = Get-ChildItem -Path $location -Filter $msiName -Recurse |
				Sort-Object -Descending -Property CreationTime |
				Select-Object -First 1 |
				ForEach-Object -Process {
					$_.FullName 
				}

			if($msiFilePath)
			{
				return $msiFilePath
			}
			else
			{
				continue
			}
		}
		else
		{
			$msiFilePath = Join-Path -Path $location -ChildPath $msiName
			if(!(Test-Path $msiFilePath))
			{
				throw "Unable to find $msiFilePath"
			}

			return $msiFilePath
		}
	}
	
	throw "Unable to find MSI named $msiName"
}

function Copy-MRInstaller
{
	[CmdletBinding()]
	Param
	(		
		[ValidateNotNullOrEmpty()]
		[string]
		$MsiFilePath,
		
		[ValidateNotNullOrEmpty()]
		[string]
		$InstallLocation
	)

	$file = Get-ChildItem -Path $MsiFilePath
	$folder = $file.Directory.FullName
	$msiLocation = Join-Path -Path $folder -ChildPath 'MRServer_x64.msi'
	$msiDestination = Join-Path -Path $InstallLocation -ChildPath 'MRServer_x64.msi'

	if($msiLocation -eq $msiDestination)
	{
		Write-LogMessage -Message "Installation media is already in place." -Verbose
	}
	else
	{
		Copy-Item -Path $msiLocation -Destination $InstallLocation -Force
		Copy-Item -Path (Join-Path -Path $folder -ChildPath 'MRServer.cab') -Destination $InstallLocation -Force
	}
	Write-LogMessage -Message "[Success] Copying installation media"
}

function Install-MRServer
{
	[CmdletBinding()]
	Param
	(
		[string]
		$SearchPath,

		[switch]
		$NoRecursive,

		[switch]
		$ForceSearchPath,

		[string]
		$LogDirectory = "$PSScriptRoot",

		[switch]
		$NoLog,

		[string]
		$InstallLocation,
		
		[switch]
		$Upgrade
	)

	# See if MR was previously installed
	$mrPaths = Get-MRFilePaths -SuppressError:(!$Upgrade)
	if(!$Upgrade -and $mrPaths)
	{
		# TODO could call this script with -Remove before proceeding (might be messy)
		throw 'A previous install of MR was detected (an unsupported scenario)'
	}

	# For upgrade, use the existing install location
	if($Upgrade)
	{
		$InstallLocation = $mrPaths.InstallLocation
	}

	$msiFilePath = Find-MRInstaller -MsiDirectoryPath $SearchPath -Server -RecursiveFind:(!$NoRecursive) -ForceMsiDirectoryPath:$ForceSearchPath

	Write-LogMessage -Message "Installing MR server from '$msiFilePath'"

	[hashtable]$properties = $null
	if($InstallLocation)
	{
		$properties = @{'INSTALLLOCATION' = $InstallLocation; 'TARGETPLATFORM' = 'Cloud'}
	}

	Install-Msi $msiFilePath -Install -Quiet -Log -LogDirectory $LogDirectory -Properties:$properties
	Install-Msi $msiFilePath -Repair -Quiet -Log -LogDirectory $LogDirectory -Properties:$properties
	Copy-MRInstaller -MsiFilePath $msiFilePath -InstallLocation $InstallLocation
	
	# Unregister performance counters and Register them back
	$installPaths = Get-MRFilePaths -SuppressError:($true)
	if($installPaths -ne $null -and (Test-Path $installPaths.Services)){
		$servicesPath = $installPaths.Services
		[Reflection.Assembly]::LoadFile("$servicesPath\Microsoft.Dynamics.Reporting.Instrumentation.dll");
		[Microsoft.Dynamics.Reporting.Instrumentation.PerformanceCounter.PerformanceCounterUtility]::UnregisterPerformanceCounters("$servicesPath\MRServicePerformanceCounter.xml");
		[Microsoft.Dynamics.Reporting.Instrumentation.PerformanceCounter.PerformanceCounterUtility]::RegisterPerformanceCounters("$servicesPath\MRServicePerformanceCounter.xml");
	}
}

function Restart-EventTraceCollection
{
	[CmdletBinding()]
	Param
	(
	)

	if($LogPath)
	{
		$mrEtwProviderPath = 'Microsoft-Dynamics-MR*'
		Write-LogMessage -Message "Restarting event tracing collection by exporting and clearing any MR event traces with provider name '$mrEtwProviderPath'"
		$eventLogDirectory = Join-Path -Path $LogPath -ChildPath 'PreviousInstallEventLogs'
		Write-LogMessage -Message "Using this directory for exporting previous event traces: $eventLogDirectory"
		# Each execution of this script should have a unique directory but for executing MRServiceModelDeployment.ps1 this won't be the case
		if(Test-Path -Path $eventLogDirectory)
		{
			Remove-Item $eventLogDirectory -Recurse -Force
		}

		[void](New-Item -Path $eventLogDirectory -ItemType Directory -Force)
		$mrLogs = wevtutil el | Where-Object { $_ -like $mrEtwProviderPath }
		if ($mrLogs)
		{
			$nonEmptyMRLogs = $mrLogs | Where-Object {
				$eventLog = wevtutil gli "$_"
				$eventLog -ne $null -and $eventLog -inotcontains 'numberOfLogRecords: 0'
			}

			if ($nonEmptyMRLogs)
			{
				$nonEmptyMRLogs | ForEach-Object { 
					Write-LogMessage -Message "Exporting $_"
					wevtutil epl "$_" "$eventLogDirectory\$($_.Replace('/', '_')).evtx" 
				}

				$nonEmptyMRLogs | ForEach-Object { 
					Write-LogMessage -Message "Clearing $_"
					wevtutil sl "$_" /e:false /q # Disable the log
					wevtutil cl "$_"          # Clear the log
					wevtutil sl "$_" /e:true /q # Re-enable the log
				}

				Write-LogMessage -Message '[Success] Exported and cleared MR event traces'
			}
			else
			{
				Write-LogMessage -Message 'All MR event traces were empty'
			}
		}
		else
		{
			Write-LogMessage -Message "No existing MR event traces were found"
		}		
	}
	else
	{
		Write-LogMessage -Message 'No LogPath specified, unable to restart event trace collection' -Warning
	}
}

$installManagementReporterScript = New-ScriptExecution -Name 'Installing Management Reporter' `
	-ErrorCode $ErrorCodes.InstallManagementReporter `
	-Script {
		if(!$NoInstall)
		{
			if((Test-Path variable:Settings) -and $Settings)
			{				
				# Some of these settings get applied here, some get applied to MRDefaultValues
				Update-ValueFromConfig -Settings $Settings -PropertyName 'MR.InstallPath' -UpdateObject:([ref]$InstallLocation) -UpdateObjectName 'InstallLocation'
			}

			Install-MRServer -SearchPath $MsiPath -NoRecursive:$ForceNonRecursiveFind -ForceSearchPath:$ForceMsiPath -LogDirectory $LogPath -InstallLocation:$InstallLocation -Upgrade:$Upgrade
			Restart-EventTraceCollection -ErrorAction Continue # Don't let this fail deployment but show errors if something doesn't work

			# Write values that include the key vault settings so other deployment components can access them
			Import-MRDeployModule
			if(!(Test-Path variable:MRDefaultValues))
			{
				$MRDefaultValues = @{}
			}
			if((Test-Path variable:Settings) -and $Settings)
			{	
				Update-ValueFromConfig -Settings $Settings -PropertyName 'Infrastructure.AzureKeyVaultAppId' -MRDefaultValues:([ref]$MRDefaultValues) -MRDefaultValueName 'KeyVaultClientId'
				Update-ValueFromConfig -Settings $Settings -PropertyName 'Infrastructure.AzureKeyVaultName' -MRDefaultValues:([ref]$MRDefaultValues) -MRDefaultValueName 'KeyVaultUrl'
				Update-ValueFromConfig -Settings $Settings -PropertyName 'Infrastructure.AzureKeyVaultCertThumbprint' -MRDefaultValues:([ref]$MRDefaultValues) -MRDefaultValueName 'KeyVaultCertThumbprint'
			
				. "$PSScriptRoot\UpdateDefaultValues.ps1"

				$writeServiceSettingsParams = Get-WriteServiceSettingsParams -ServiceType Services
				Write-ServiceSettings @writeServiceSettingsParams
				Write-MRStepMessage 'Writing service settings to deployment config file (Write-DeploymentConfigSettings)'
				$deploymentWriteConfigSettingsParams = Get-WriteDeploymentConfigSettingsParams
				Write-DeploymentConfigSettings @deploymentWriteConfigSettingsParams
				[System.Configuration.ConfigurationManager]::RefreshSection("appSettings")
				Write-MRInfoMessage 'Wrote deployment application configuration settings' -Success
			}

		}
		else
		{
			$result = Test-MRInstalled
			if(!$result)
			{
				throw 'MR is not installed and -NoInstall was specified'
			}
		}
	}

Invoke-ExecutionScript -ExecutionScript $installManagementReporterScript
# SIG # Begin signature block
# MIIjsAYJKoZIhvcNAQcCoIIjoTCCI50CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCXgIEVJeR+Lfrn
# IGJQKqz6njJDuGcC8hueiVPhbooy66CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVhTCCFYECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgeKDXV3An
# dKHFzc2CikE2ObDrSydC9rfS7jsRVBXV8gcwbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQAzDQ+z+A0rdkONPUxBgmewONvTgsJvQaYa7/pkW6O3tuQJYqtd
# ZINCEI5ihsL+feC41tOkSFzoR4erfgJVfc9kAFmy6e3tKQZBInQIK8eDm+a/rPip
# RUPCDQMC6f8dNgA3V6I1PhoHRMLGuUxVwerlfgA4uz+5Whr7A1GJzi1VymPHgZ6G
# 4JEK3lRgvs7WNXiX5I33pgr+TOZb9iWNG3ebPLmyetf+pzpvjOythfqjYspaAxiD
# RDpjgNTlhqqHQXP9P5o53Wr7AaZoOXpqZWInJf0tDd7Vr4XPN0am/UxrFHyUwnrq
# +IikxgNALHruSm9TqxX4jFhVWquBLt82vcaaoYIS5TCCEuEGCisGAQQBgjcDAwEx
# ghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIFxYbPzRXJ8NnyX0KwXi9KaJvynCXsDmOVHdlvjfE8y7AgZd
# XcYqeFsYEzIwMTkwOTE3MTkyMDU5Ljk0OVowBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29m
# dCBBbWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkQ2
# QkQtRTNFNy0xNjg1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAAD1dBs8ihcrfO0AAAAAAPUwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgxMDI0
# MjExNDI2WhcNMjAwMTEwMjExNDI2WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0
# aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RDZCRC1FM0U3LTE2ODUxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQDELN7SEzp5hZ8BwF/wt91kQ21AU+epo79+N8CA
# c3fQ/IgXEiApZd8y3o77nKuid2A/ggWPw21kS+ZSGUGNk0jpI19ez1o+jyugPpQd
# 1POYXbBdK980hWTuZ6Y92HEjvOSqc/ecRnYSGDM02HBT96oKjmsJ/xhfq/VjycHw
# 9tUjtAYlSE4QKTBQHTfe2szgYJoJeOP2QNXtf7awiowqiaWcm9piEyHhusDJLn4+
# Cf26zDzG9iQ7xRnyGJjoxEPcCE7Ufif3E3PCwOBsSZ7rAFgPVnbT3MnpqXewpe1y
# j/suld+eKa9h67ZcGAh/+wFm4GO0aAGr25jL2paiQ2jPY45zAgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQU22B358rXYFzlBt7DYkxqxlFeYGQwHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEAn6RsJd9757HGRSaVFo9wHhmKQQnveUrepEcKPyZXX44MQf5P
# vBLkAHZbWe68h/MomX6j/wR4B01r0HrEcc9GmtGDU/7L85Ekwvfm10JdGoB6ywVu
# lBUXwkKaDsmAgOT0+GfqckTLkjaExkpvLLA8El5+e85dX8szlZ2KP/0CfKEGHNOC
# 4g6YZR7cXQfwWhA5HGZz6kYSmMWRfxQsaAn3kGXhN5YkAvhxIPoRggtVxngX5VGF
# fbyOPajEnzY4qhhO75frhFy4849ebs0EbZHHR5y/lyLuKzbi/mDA/0sF7RFp990g
# jOSrZETZcc8HcleoRCNbU5vSFP+8IlEMH/IoijCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRp
# b25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpENkJELUUzRTctMTY4NTElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAgKEJxzINtJPUmw4vYqMtHpCyKsaggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOErM9owIhgPMjAxOTA5MTcx
# ODI4NDJaGA8yMDE5MDkxODE4Mjg0MlowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA
# 4Ssz2gIBADAKAgEAAgIQnAIB/zAHAgEAAgIRuDAKAgUA4SyFWgIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYag
# MA0GCSqGSIb3DQEBBQUAA4GBAD1YaDJO2UPRMzoKbCppQF2wEISXnZ9kFsTVKXTL
# jiepEYQkJksLtVHUD8DrDI+SG6k2HQHSBAVwevFGKb18Bq5XL4MRrqDHE0xBkjbz
# /6P/yksS5c+XHtRmhd5LDoan+puxH3KVAySiJWXTjcSaT7JgNyX0/TPDEte4EraU
# dlZ+MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAAD1dBs8ihcrfO0AAAAAAPUwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgWQrYsOrxvtZSK3uw
# OTGT3+Z60YD57oSV5ko8XVpRO0wwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCC5nplCX6D6cMNzRTUiRyiZbMKyY6NtsJepz0L2fJMfcDCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA9XQbPIoXK3ztAAAAAAD1MCIE
# IKGuG9B6JmtEWOuahXvKc7liJP/KI6GxrUPTcyfVRGRnMA0GCSqGSIb3DQEBCwUA
# BIIBAIYOuE0N4o5oXycXYp8k4w0YhxI8TN0vGjhbSu2xcr6EbN2fFbcWjpXWw4uH
# lkJwb52liV0G8NkEz4tHfjYCXkjywfl3YLqD8xP473ITBcfeKRJCjXxRpCLY9J9G
# U+5vy0qh8Aj7V5ANQE9r6omOvM7H7avS4UhSORzIdDWFT8Hu+jsTFRsUM9t9s/oa
# SmJsD6JJizm96/rkAjMxPj+b0rxw4L74l6SYgH+NJd/2Y0FPF2vicW2zPuw1zcrV
# TGUsgjOx27A6PfxyiBoT/FkC7xXxMlWj6u3AXXyRvVHF7fjYKScsqWjE3FOrA45V
# TeMQ6PqyKB2Q6Lod6LQQ2wyP2ig=
# SIG # End signature block
