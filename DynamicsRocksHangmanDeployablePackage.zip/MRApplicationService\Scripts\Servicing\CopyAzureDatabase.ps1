﻿<#
.Synopsis
Runs the required steps to configure the MR database for a new environment
#>
[CmdletBinding()]
Param
(
	# Name of the server hosting the source database
	[string]
	[ValidateNotNullOrEmpty()]
	$SourceDatabaseServerName,
	
	# Name of the source database
	[string]
	[ValidateNotNullOrEmpty()]
	$SourceDatabaseName,
	
	# Name of the user for connecting to the source database
	[string]
	[ValidateNotNullOrEmpty()]
	$SourceUserName,
	
	# Password of the user for connecting to the source database
	[string]
	[ValidateNotNullOrEmpty()]
	$SourceUserPassword,
	
	# Name of the server hosting the target database
	[string]
	[ValidateNotNullOrEmpty()]
	$TargetDatabaseServerName,
	
	# Name of the target database
	[string]
	[ValidateNotNullOrEmpty()]
	$TargetDatabaseName,
	
	# Name of the user for connecting to the target database
	[string]
	[ValidateNotNullOrEmpty()]
	$TargetUserName,
	
	# Password of the user for connecting to the target database
	[string]
	[ValidateNotNullOrEmpty()]
	$TargetUserPassword,

	# User name for the admin user in the MR database on the target environment
	[string]
	[ValidateNotNullOrEmpty()]
	$AdminUserName = 'mradminuser',
	
	# Password for the admin user in the MR database on the target environment
	[string]
	[ValidateNotNullOrEmpty()]
	$AdminUserPassword,

	# User name for the lower-privileged user in the MR database on the target environment
	[string]
	[ValidateNotNullOrEmpty()]
	$RuntimeUserName = 'mrruntimeuser',
	
	# Password for the lower-privileged user in the MR database on the target environment
	[string]
	[ValidateNotNullOrEmpty()]
	$RuntimeUserPassword,

	# Path to log file
	[string]
	[ValidateNotNullOrEmpty()]
	$LogFilePath = (Join-Path -Path $PSScriptRoot -ChildPath "MR_CopyAzureDatabase_$(Get-Date -Format yyyyMMdd-HHmmss).log")
)

$ErrorActionPreference = 'stop'
$azureDatabaseDomain = '.database.windows.net'
if($SourceDatabaseServerName -notlike "*$azureDatabaseDomain")
{
	$SourceDatabaseServerName = $SourceDatabaseServerName + $azureDatabaseDomain
}

if($TargetDatabaseServerName -notlike "*$azureDatabaseDomain")
{
	$TargetDatabaseServerName = $TargetDatabaseServerName + $azureDatabaseDomain
}

$upgradeSqlUser = 'mrupdateuser'
$upgradePassword = $TargetUserPassword
$sqlUsers = 
@(
	@{ UserId = $RuntimeUserName; Password = $RuntimeUserPassword; Roles = @('db_datareader', 'db_datawriter', 'GeneralUser') }
)

$sqlLogins =
@(
	@{ UserId = $AdminUserName; LogIn = $AdminUserName }
)

$sourceSqlParams = @{
	'Database' = ''
	'UserName' = $SourceUserName
	'Password' = $SourceUserPassword
	'ServerInstance' = $SourceDatabaseServerName
	'EncryptConnection' = $true
	'Query' = ''
}

$targetSqlParams = @{
	'Database' = ''
	'UserName' = $TargetUserName
	'Password' = $TargetUserPassword
	'ServerInstance' = $TargetDatabaseServerName
	'EncryptConnection' = $true
	'Query' = ''
	'QueryTimeout' = 0
}

######################
### Helper methods ###
######################

function New-SqlLogin
{
	[CmdletBinding()]
	Param
	(
		[Hashtable]
		[ValidateNotNull()]
		$SqlParams,

		[string]
		[ValidateNotNullOrEmpty()]
		$NewUser,

		[string]
		[ValidateNotNullOrEmpty()]
		$Password
	)

	$createLoginQuery = @"
	IF NOT EXISTS (SELECT name FROM sys.sql_logins WHERE name = '$NewUser')
	BEGIN
		CREATE LOGIN [$NewUser] WITH PASSWORD = N'$Password'
	END
	ELSE
	BEGIN
		ALTER LOGIN [$NewUser] WITH PASSWORD = N'$Password'
	END
"@

	$SqlParams.Query = $createLoginQuery
	[void](Invoke-Sqlcmd @SqlParams)
}

function Remove-SqlLogin
{
	[CmdletBinding()]
	Param
	(
		[Hashtable]
		[ValidateNotNull()]
		$SqlParams,

		[string]
		[ValidateNotNullOrEmpty()]
		$Login
	)

	$dropLoginQuery = @"
	IF EXISTS (SELECT name FROM sys.sql_logins WHERE name = '$Login')
	BEGIN
		DROP LOGIN [$Login]
	END
"@

	$SqlParams.Query = $dropLoginQuery
	[void](Invoke-Sqlcmd @SqlParams)
}

function New-UserForLogin
{
	[CmdletBinding()]
	Param
	(
		[Hashtable]
		[ValidateNotNull()]
		$SqlParams,

		[string]
		[ValidateNotNullOrEmpty()]
		$NewUser
	)

	$createUserQuery = @"
	IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = '$NewUser' AND TYPE = 'S')
	BEGIN
		CREATE USER [$NewUser] FOR LOGIN [$NewUser] WITH DEFAULT_SCHEMA = [dbo]
	END
"@

	$SqlParams.Query = $createUserQuery
	[void](Invoke-Sqlcmd @SqlParams)
}

function Remove-User
{
	[CmdletBinding()]
	Param
	(
		[Hashtable]
		[ValidateNotNull()]
		$SqlParams,

		[string]
		[ValidateNotNullOrEmpty()]
		$User
	)

	$dropUserQuery = @"
	IF EXISTS(SELECT name FROM sys.database_principals WHERE name = '$User' AND TYPE = 'S')
	BEGIN
		DROP USER [$User]
	END
"@

	$SqlParams.Query = $dropUserQuery
	[void](Invoke-Sqlcmd @SqlParams)
}

function New-UserWithPassword
{
	[CmdletBinding()]
	Param
	(
		[Hashtable]
		[ValidateNotNull()]
		$SqlParams,

		[string]
		[ValidateNotNullOrEmpty()]
		$NewUser,

		[string]
		[ValidateNotNullOrEmpty()]
		$Password
	)

	$createUserQuery = @"
	IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = '$NewUser' AND TYPE = 'S')
	BEGIN
		CREATE USER [$NewUser] WITH PASSWORD = N'$Password'
	END
	ELSE
	BEGIN
		ALTER USER [$NewUser] WITH PASSWORD = N'$Password'
	END
"@

	$SqlParams.Query = $createUserQuery
	[void](Invoke-Sqlcmd @SqlParams)
}

function Edit-UserWithLogIn
{
	[CmdletBinding()]
	Param
	(
		[Hashtable]
		[ValidateNotNull()]
		$SqlParams,

		[string]
		[ValidateNotNullOrEmpty()]
		$User,

		[string]
		[ValidateNotNullOrEmpty()]
		$Login
	)

	$alterUserQuery = @"    
		ALTER USER [$User] WITH LOGIN = [$Login]
"@

	$SqlParams.Query = $alterUserQuery
	[void](Invoke-Sqlcmd @SqlParams)
}

function Add-UserToRole
{
	[CmdletBinding()]
	Param
	(
		[Hashtable]
		[ValidateNotNull()]
		$SqlParams,

		[string]
		[ValidateNotNullOrEmpty()]
		$User,

		[string]
		[ValidateNotNullOrEmpty()]
		$Role
	)

	$alterRoleQuery = @"
	IF IS_ROLEMEMBER('$Role', '$User') = 0
	BEGIN
		ALTER ROLE [$Role] ADD MEMBER [$User]
	END 
"@

	$SqlParams.Query = $alterRoleQuery
	[void](Invoke-Sqlcmd @SqlParams)
}

try
{
	#########################################
	### Create temporary user for copying ###
	#########################################

	# Create user in source sql server to perform database copy operation.
	$sourceSqlParams.Database = 'master'
	New-SqlLogin -SqlParams $sourceSqlParams -NewUser $upgradeSqlUser -Password $upgradePassword
	New-UserForLogin -SqlParams $sourceSqlParams -NewUser $upgradeSqlUser
	Add-UserToRole -SqlParams $sourceSqlParams -User $upgradeSqlUser -Role 'dbmanager'

	$sourceSqlParams.Database = $SourceDatabaseName
	New-UserForLogin -SqlParams $sourceSqlParams -NewUser $upgradeSqlUser
	Add-UserToRole -SqlParams $sourceSqlParams -User $upgradeSqlUser -Role 'db_owner'

	# Create user in target sql server to perform database copy operation.
	$targetSqlParams.Database = 'master'
	New-SqlLogin -SqlParams $targetSqlParams -NewUser $upgradeSqlUser -Password $upgradePassword
	New-UserForLogin -SqlParams $targetSqlParams -NewUser $upgradeSqlUser
	Add-UserToRole -SqlParams $targetSqlParams -User $upgradeSqlUser -Role 'dbmanager'

	###########################################
	### Get Service Level from Target DB     ###
	###########################################
	$targetSqlParams.Database = $TargetDatabaseName
	$targetSqlParams.Query = @"
	SELECT DATABASEPROPERTYEX('$TargetDatabaseName', 'ServiceObjective')
"@
	$level = Invoke-Sqlcmd @targetSqlParams

	if($level)
	{
		$levelValue = $level.Column1
	}
	if([string]::IsNullOrEmpty($levelValue)){
		$levelValue = 'P2'
	}

	###########################################
	### Rename target databases i.e. backup ###
	###########################################
	$targetSqlParams.Database = 'master'
	$targetSqlParams.Query = @"
	IF NOT EXISTS (SELECT 'x' FROM SYS.DATABASES WHERE NAME = '$($TargetDatabaseName + '_orig')')
	BEGIN
		ALTER DATABASE [$TargetDatabaseName] MODIFY NAME = [$($TargetDatabaseName + '_orig')]
	END
"@
	Invoke-Sqlcmd @targetSqlParams

	##########################################################
	### Validate sql user passwords against the current DB ###
	##########################################################
	$targetSqlParams.Database = $TargetDatabaseName + '_orig'
	foreach($sqluser in $sqlUsers)
	{
		"Testing password for $($sqlUser.UserId)"
		$targetSqlParams.UserName = $sqlUser.UserId
		$targetSqlParams.Password = $sqluser.Password
		$targetSqlParams.Query = "SELECT @@ERROR"
		[void](Invoke-Sqlcmd @targetSqlParams)
	}

	############################################
	### Copy databases from source to target ###
	############################################
	$targetSqlParams.Database = 'master'
	$targetSqlParams.UserName = $upgradeSqlUser
	$targetSqlParams.Password = $upgradePassword
	$targetSqlParams.Query = "CREATE DATABASE [$($TargetDatabaseName)] as copy of [$($sourceSqlParams.ServerInstance.Split('.')[0])].[$($SourceDatabaseName)] (SERVICE_OBJECTIVE = '$levelValue')"
	Write-Output $(Get-Date)
	Invoke-Sqlcmd @targetSqlParams -ErrorAction Continue

	# Validate that we have the copied database
	# This step is required because CREATE DATABASE
	# will give an error even when successful.
	$targetSqlParams.Query = "SELECT COUNT(*) FROM sys.databases WHERE name in ('$TargetDatabaseName')"
	# Wait a few seconds before checking
	Start-Sleep -Seconds 30
	$result = Invoke-SqlCmd @targetSqlParams

	if (($result -eq $null) -bor ($result[0] -eq 0))
	{
		throw 'Database copy failed.'
	}

	# Wait for copy to complete
	$targetSqlParams.Database = 'master'
	$targetSqlParams.UserName = $TargetUserName
	$targetSqlParams.Password = $TargetUserPassword
	$targetSqlParams.Query = "SELECT state, name FROM sys.databases WHERE name in ('$TargetDatabaseName') and state != 0"
	$result = Invoke-SqlCmd @targetSqlParams
	while ($result -ne $null)
	{
		$result
		'Waiting 30 seconds for database copy to complete.'
		Start-Sleep -Seconds 30
		$result = Invoke-Sqlcmd @targetSqlParams
	}

	Write-Output $(Get-Date)

	###############################
	### Set compatibility level ###
	###############################
	$targetSqlParams.Query = "select compatibility_level from sys.databases where name = '$($TargetDatabaseName)_orig'"
	$compatResult = Invoke-Sqlcmd @targetSqlParams

	$targetSqlParams.Query = "ALTER DATABASE [$TargetDatabaseName] SET COMPATIBILITY_LEVEL = $($compatResult.compatibility_level)"
	Invoke-Sqlcmd @targetSqlParams

	##################################################
	### Copy scoped configuration from original DB ###
	##################################################

	# Get the scoped configuration from original DB.
	$targetSqlParams.Database = "$($TargetDatabaseName)_orig"
	$targetSqlParams.Query = "SELECT * from sys.database_scoped_configurations"
	$origConfigs = Invoke-Sqlcmd @targetSqlParams

	# Exrpression to format value.
	$normalizeValue = @'
		if ($origConfigValue -is [System.DBNull])
		{
			return "PRIMARY"
		}
	
		if ($origConfigValue -is [System.Boolean])
		{
			if ($origConfigValue) { return 'ON' } else { return 'OFF' }
		}

		if ($origConfigValue -is [System.Int32])
		{
			return $origConfigValue
		}

		return "'$origConfigValue'"
'@

	if ($origConfigs -ne $null)
	{
		# Iterate and copy values to target DB.
		$targetSqlParams.Database = "$TargetDatabaseName"
		foreach($origConfig in $origConfigs)
		{
			$origConfigValue = $origConfig.value
			$normalizedConfigValue = Invoke-Expression $normalizeValue
			$targetSqlParams.Query = "ALTER DATABASE SCOPED CONFIGURATION SET $($origConfig.name) = $normalizedConfigValue"
			Invoke-Sqlcmd @targetSqlParams

			if ($origConfig.name -ne 'IDENTITY_CACHE')
			{
				$origConfigValue = $origConfig.value_for_secondary
				$normalizedConfigValue = Invoke-Expression $normalizeValue
				$targetSqlParams.Query = "ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET $($origConfig.name) = $normalizedConfigValue"
				Invoke-Sqlcmd @targetSqlParams
			}
		}
	}

	#################################################
	### Add AxDB sql users to the copied database ###
	#################################################
	$targetSqlParams.Database = $TargetDatabaseName
	foreach($sqluser in $sqlUsers)
	{
		New-UserWithPassword -SqlParams $targetSqlParams -NewUser $sqluser.UserId -Password $sqluser.Password
		foreach($role in $sqluser.Roles)
		{
			Add-UserToRole -SqlParams $targetSqlParams -User $sqluser.UserId -Role $role
		}
	}

	foreach($sqluser in $sqlLogins)
	{
		Edit-UserWithLogIn -SqlParams $targetSqlParams -User $sqluser.UserId -Login $sqluser.LogIn
	}
}
catch
{
	Write-Host $_
}
finally
{
	#############################
	### Delete temporary user ###
	#############################
	
	# Remove user from source sql server.
	$sourceSqlParams.Database = $SourceDatabaseName
	Remove-User -SqlParams $sourceSqlParams -User $upgradeSqlUser

	$sourceSqlParams.Database = 'master'
	Remove-User -SqlParams $sourceSqlParams -User $upgradeSqlUser
	Remove-SqlLogin -SqlParams $sourceSqlParams -Login $upgradeSqlUser
	
	# Remove user from target sql server.
	$sourceSqlParams.Database = $TargetDatabaseName
	Remove-User -SqlParams $targetSqlParams -User $upgradeSqlUser

	$targetSqlParams.Database = 'master'
	Remove-User -SqlParams $targetSqlParams -User $upgradeSqlUser
	Remove-SqlLogin -SqlParams $targetSqlParams -Login $upgradeSqlUser
}
# SIG # Begin signature block
# MIIjsAYJKoZIhvcNAQcCoIIjoTCCI50CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDdW6o7SZ7sqYqb
# YWaaTts7pJ40laLbuJIjcerzihGIDKCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVhTCCFYECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg+VVLbAl5
# X2G91J6VsTPA03P/8qC5sOq1CI3SL7WFc0owbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQBh9saYWvXswkO0zYFGY8cS2CgGDCCMRCi6XX/6Ti8CgK/gdIBk
# qMnzVXctunw6PUpKKHNEjK8r0OUge65C1YWx4vefr1Mr8bDk6blAPTLOinWSwmq8
# vlS9dPj0nG2VhxX0pOvQCr3EzC14/SWKxnl9bBORWl0ll07IHey1cKAOCCOGLWDQ
# 9WTIc3h+OqJetNgut+7gNrs7xmLpsZyxt9sktnvPQ6KVgpMj0II/UaXV+R+z7jZ9
# gnVoloRbS3V8f86TQ+RR+qm22KPr3PRUi9JbA0WFIQp3GcyoM+lBOG0X68UC8cnl
# JpQ/eC8RIEM50xEez6RlThMQKKqayn+6VpuxoYIS5TCCEuEGCisGAQQBgjcDAwEx
# ghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIJcl1vpgzQvUVyke0tCb2Mtvqw06cRoBj3H51ffSyusyAgZd
# XuX6SVAYEzIwMTkwOTE3MTkyMDAzLjA0NFowBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkE4
# NDEtNEJCNC1DQTkzMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBzZXJ2
# aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAADd5N467K3z8dQAAAAAAN0wDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgwODIz
# MjAyNjU5WhcNMTkxMTIzMjAyNjU5WjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QTg0MS00QkI0LUNBOTMxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCNhxU/qetKYqDxcRdCRR9BXZH5rZ0mDO/SJQob
# i+YJ/CZx0znu5bzj4oTe/m8r4DFG/6Gcy7R4YFmDTS6/doxp7OOWwvQ9lxQyTX2W
# pBL3qRvqvFDVyUZaapRDO9B/7a58E7/2rkd006gwW46Jd/fuyT5H9IgPBIfBZl7L
# Cn23XOFVEAbCV7B2HOVggZcuVe5qbib03exeo8LgLn6XkzhkkbY8MmVX69Bn/ZpW
# JshWY8HWTRgdWLwm1H78lt7IuWCmYrZsQiEyy0zWITv+clmKQPmUOvreIREEkzZ+
# pAaglb5VhQYSjR9cDE9t6NVM1gZOz/ZhsiqnU7PEAWwsBnwtAgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQUd1H29snoYiOlhuljLH2W8OjqjzkwHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEAJcx57iq++wawqCNMBQivWvy5Ue4X/nOdf1+tpqMiAqAgkqU5
# NbOAh3ISbVshq8wp5deRcxGIhV6YZmXJkIUOgtsOqihWlpZoyVdZ0wLzRYJan4Xw
# dKtRUtbM2IKerQc8yeplOpjucJieM4BLASAiIFtxmLjWdYUc/1MUN2bjD2Ms+cWo
# wvZna3FiSTJP2dL6nwTOpqOk8WpaSLDukuzPzTvV3Tk04IVYEgMpF2b8X9cuDVzl
# gG/3S1V6d398x1T0Fdd6immSjdwLxaPudL/zxvTSTbB3GFFDV9qdERwIAj2oSdwB
# pOi7W8TV4ODzlkjwYsiYnz+hmaR3iY4f6wKTQjCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpBODQxLTRCQjQtQ0E5MzElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUA6aXe1WKnOeD4xeVOaSva42mPCHiggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOErqwwwIhgPMjAxOTA5MTgw
# MjU3MTZaGA8yMDE5MDkxOTAyNTcxNlowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA
# 4SurDAIBADAKAgEAAgIUjgIB/zAHAgEAAgISEzAKAgUA4Sz8jAIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYag
# MA0GCSqGSIb3DQEBBQUAA4GBAIITrCHsGsRDdEZQgDiDPoFyswLNMsN6B/xyaaVd
# vZgUdNMXgCHMwH60L3U6OgFSxpT99Nd8KClQwrYQ0XqmNoTTryhrC0c7adGe+cJz
# 3MNEuQXvMNwIxFdGnx1FM8lomjf1scazHGr3hMSc68NZtXwO7jO3MpOwYiqgpC3N
# q5mZMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAADd5N467K3z8dQAAAAAAN0wDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQg8AdO7J8angivUj2o
# eGsn5hTiIXTZ2Uq+Ebw09Vap3GMwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCBK4OJw84dqPy8kOOptHP1QuD64kFPi8JILfK/HX+hYGDCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA3eTeOuyt8/HUAAAAAADdMCIE
# IEh5T3prlmLo7synoTbn6PJ9KOJ7iFMVWLauL0LdrIO9MA0GCSqGSIb3DQEBCwUA
# BIIBAFK3rK7yLXkxFfl9Qmqlb77ixau+SdZnhcbSnmb8UR+sBukiWDGUqqwILfa6
# 5/5CteZfvWJo8KG1WU1ANpPTVfdSZTvMTj3b1aJMghy8zivBC3c3bY83jGJRdFz0
# rISX3VUPlZfu4VKfIk1wlWE4VkDl0xHmNBy0Q6H/tCVf6hezrk31Wqp02dRrI7my
# UW+m5sklRXU2SKRROp7Xl23m9BuJVRNXLgBt/KwI4/sw4MLSvHvHv1+H4kOYvi23
# nTQ7BvjDh5/s8cxjRhKF41YCfgWH08bS+PzhZu1HHKQuOhh9+YhFmsk8ZC+JRczI
# PonUzVgmIixDAlVXutjoapFQQYQ=
# SIG # End signature block
