DECLARE @tableName NVARCHAR(100)
DECLARE @indexName NVARCHAR(500)
DECLARE @columnstoreSql NVARCHAR(1000)

IF [Datamart].IsColumnstoreSupported() = 0
BEGIN
	PRINT 'Dropping columnstore indexes'
	
	DECLARE columnstoreTableCursor CURSOR LOCAL FAST_FORWARD FOR
		SELECT t.name, i.name
		FROM sys.indexes i 
		INNER JOIN sys.tables t ON i.object_id = t.object_id 
		INNER JOIN sys.schemas s on t.schema_id = s.schema_id
		WHERE s.name = 'Datamart' and i.type = 5 -- Type 5 is clustered columnstore
		
	OPEN columnstoreTableCursor
	FETCH NEXT FROM columnstoreTableCursor INTO @tableName, @indexName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @columnstoreSql = 'DROP INDEX ' + @indexName + ' ON Datamart.' + @tableName
		PRINT (@columnstoreSql)
		EXEC (@columnstoreSql)
		FETCH NEXT FROM columnstoreTableCursor INTO @tableName, @indexName
	END
	CLOSE columnstoreTableCursor
	DEALLOCATE columnstoreTableCursor
END

IF [Datamart].IsColumnstoreSupported() = 1
BEGIN
	PRINT 'Dropping columnstore indexes not in our list'
	DECLARE columnstoreTableCursor CURSOR LOCAL FAST_FORWARD FOR
		SELECT t.name, i.name
		FROM sys.indexes i 
		INNER JOIN sys.tables t ON i.object_id = t.object_id 
		INNER JOIN sys.schemas s on t.schema_id = s.schema_id
		WHERE s.name = 'Datamart' and i.type = 5 -- Type 5 is clustered columnstore
			AND t.name COLLATE DATABASE_DEFAULT not in (select tableName from [Datamart].GetColumnstoreTables())
		
	OPEN columnstoreTableCursor
	FETCH NEXT FROM columnstoreTableCursor INTO @tableName, @indexName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @columnstoreSql = 'DROP INDEX ' + @indexName + ' ON Datamart.' + @tableName
		PRINT (@columnstoreSql)
		EXEC (@columnstoreSql)
		FETCH NEXT FROM columnstoreTableCursor INTO @tableName, @indexName
	END
	CLOSE columnstoreTableCursor
	DEALLOCATE columnstoreTableCursor
END

PRINT 'Reconfiguring indexes'
EXEC Datamart.ConfigureIndexesAndConstraints