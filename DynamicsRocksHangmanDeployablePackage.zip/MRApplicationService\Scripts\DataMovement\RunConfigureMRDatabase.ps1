﻿# This script is a wrapper to call the ConfigureMRDatabase.ps1 from MR Service module.

[CmdletBinding()]
param
(
  [Parameter(Mandatory=$true)]
  [hashtable]$Credentials,
  [Parameter(Mandatory=$false)]
  [string]$LogDir
)

# Following parameters are required by configureMRDatabase scripts. They should not be null.
if(!$Credentials -or !$Credentials['axmrruntimeuser']) { throw 'Parameter $Credentials[axmrruntimeuser] must not be null or empty.' }
if(!$Credentials -or !$Credentials['mrruntimeuser']) { throw 'Parameter $Credentials[mrruntimeuser] must not be null or empty.' }
if(!$Credentials -or !$Credentials['mradminuser']) { throw 'Parameter $Credentials[mradminUser] must not be null or empty.' }
if(!$Credentials -or !$Credentials['axdeployuser']) { throw 'Parameter $Credentials[axdeployuser] must not be null or empty.' }

$script:currentFolder = (Get-ChildItem -Path (Split-Path -Path $PSScriptRoot -Parent) -Recurse -Filter RunConfigureMRDatabase.ps1 | Select-Object -First 1).Directory.FullName
$CommonMRUpgradeFunctionsPath = Join-Path -Path $script:currentFolder -ChildPath "..\Update\CommonMRUpgradeFunctions.ps1"
$CommonMRUpgradeFunctionsPath  = Resolve-Path $CommonMRUpgradeFunctionsPath 
. "$CommonMRUpgradeFunctionsPath"

if (!$LogDir)
{
  $LogDir = Get-LogPath -ResolvedRunbookLogFolder '$RunbookLogFolder'
}

Set-LogPath -LogDir $LogDir -LogFileName 'RunConfigureMRDatabase'

$MREnvironmentUtilitiesPath = Join-Path -Path $script:currentFolder -ChildPath "MREnvironmentUtilities.ps1"
$MREnvironmentUtilitiesPath = Resolve-Path -Path $MREnvironmentUtilitiesPath
. "$MREnvironmentUtilitiesPath"

$AOSUtilitiesPath = Join-Path -Path $script:currentFolder -ChildPath "..\..\..\AOSService\Scripts\AosEnvironmentUtilities.psm1"
Import-Module "$AOSUtilitiesPath" -Force -DisableNameChecking

$EnvCreds = Get-Env-Credentials
$axdbName = Get-DataAccessDatabase
$axServerName = Get-DataAccessDbServer
$mrServerName = $EnvCreds['mrdbServer']

$mrdbName = $EnvCreds['mrdbName']
$axmrruntimeUser = 'axmrruntimeuser'
$axmrruntimePwd = $Credentials['axmrruntimeuser']
$mradminUser = 'mradminuser'
$mradminPwd = $Credentials['mradminuser']
$mrruntimeUser = 'mrruntimeuser'
$mrruntimePwd = $Credentials['mrruntimeuser']
$azureDatabaseDomain = '.database.windows.net'

# Update the database server to fqdn
if ($axServerName -notlike "*$azureDatabaseDomain")
{
  $axServerName = $axServerName + $azureDatabaseDomain
}

if($mrServerName -notlike "*$azureDatabaseDomain")
{
  $mrServerName = $mrServerName + $azureDatabaseDomain
}

# Pass axdeployuser credentials for databases on MR version 7.1 and 7.0, otherwise pass axdbadmin credentials
# TO DO: Always pass axdbadmin credentials once MR team fixes this dependency
$target_sqlParams = @{
    'Database' = $mrdbName
    'UserName' = $mradminUser
    'Password' = $mradminPwd
    'ServerInstance' = $mrServerName
    'EncryptConnection' = $mrServerName.endswith("database.windows.net")
    'Query' = ''
    'QueryTimeout' = 300 # 5 minute timeout
    'ConnectionTimeout' = 120 # 2 minute timeout
  }

  $target_sqlParams.Query = @"
select Value from reporting.controlproperties where Name = 'SchemaVersion'
"@

$mrVersion = (Invoke-Sqlcmd @target_sqlParams).Value

If ($mrVersion -like "7.1*" -or $mrVersion -like "7.0*")
{
    $axUserName = 'axdeployuser'
    $axUserPwd = $Credentials['axdeployuser']
}
else
{
    $axUserName = Get-DataAccessSqlUsr
    $axUserPwd = Get-DataAccessSqlPwd
}

# Run ConfigureMRDatabase
$configMRscriptpath = Join-Path -Path $script:currentFolder -ChildPath "..\Update\ConfigureMRDatabase.ps1"
$configMRscriptpath = Resolve-Path -Path $configMRscriptpath
&$configMRscriptpath -NewAosDatabaseName: $axdbName -NewAosDatabaseServerName: $axServerName -NewMRDatabaseServerName: $mrServerName -NewMRDatabaseName: $mrdbName -NewAxAdminUserName: $axUserName -NewAxAdminUserPassword: $axUserPwd -NewAxMRRuntimeUserName: $axmrruntimeUser -NewAxMRRuntimeUserPassword: $axmrruntimePwd -NewMRAdminUserName: $mradminUser -NewMRAdminUserPassword: $mradminPwd -NewMRRuntimeUserName: $mrruntimeUser -NewMRRuntimeUserPassword: $mrruntimePwd
# SIG # Begin signature block
# MIIjrwYJKoZIhvcNAQcCoIIjoDCCI5wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB8AYfENOJwum1F
# 3ncp35nF+EDIYxkkIYJyUszkK5Kvn6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVhDCCFYACAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgJ5ANlvI+
# Nt/Ul6wU7IuE4rIRgGwXuBUFmECIIuICwMUwbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQBr2wbZdX5TVbxoaExZ2jtYeLpnx75q4p8JVBMVAba7x9tUHNnc
# tsBcwdjBGpoSkZ8NZxrmDGUOJc835UNSxs8XqP52zVAaDL/451S0CC1QKrGAqvmm
# Vrxv1jxkY6j7MTT3NOnMKpqtup72/xbeFwJebdKsrUrpJ6hJ3i0tL8s8XfvN8meU
# y5bBTfHj2XEA7YNWzRGeUO4mTSjGpgX7YgIxEcSsE2Q8palOIj4l2MjwCQdcU7nw
# 9YJEq7b/KsqDK5PyWRQIzXDtCVl5t7ifvxgpnB/ixqbgD8YZZrs88SRjtVuYX6n9
# WvWv+ozebcA+Gv/kVFRXULipvlv9R/nZuu+6oYIS5DCCEuAGCisGAQQBgjcDAwEx
# ghLQMIISzAYJKoZIhvcNAQcCoIISvTCCErkCAQMxDzANBglghkgBZQMEAgEFADCC
# AVAGCyqGSIb3DQEJEAEEoIIBPwSCATswggE3AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIGPyMHfXgqyIOifDSUxRxFzEmblNkx269gGEomN2lbHCAgZd
# XuYF1fUYEjIwMTkwOTE3MTkyMDAxLjI4WjAEgAIB9KCB0KSBzTCByjELMAkGA1UE
# BhMCVVMxCzAJBgNVBAgTAldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5k
# IE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046OEU5
# RS00QkQwLTJFRDAxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZp
# Y2Wggg48MIIE8TCCA9mgAwIBAgITMwAAAN+ujcXQrkI3zwAAAAAA3zANBgkqhkiG
# 9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMy
# MDI3MDFaFw0xOTExMjMyMDI3MDFaMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo4RTlFLTRCRDAtMkVEMDElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZTCCASIwDQYJKoZIhvcN
# AQEBBQADggEPADCCAQoCggEBAKipFuteBxQ6zDspLG+dLhYPlFbjMzA7+njcNMb4
# EEZC7zg+dtsGCCcDWJypmY9zBH757s+ePborHARrw7X/+W2xVKkLzWDo2oYEcAPG
# b4qvlRAvRofMe7n0r5AeCQII2eHUnjt61kWI8tUpNQ2oAqzQBZbdzyOHQGnig5i+
# OxjtBRPGqqSPG/CkTT8R4Bueaw2W8VpU3lPAwrVZLtVG01o0jaaenBI0AG237ja9
# izgvLV1AjrCJ6nwDv/iP354htLAG7I0ai6NlmpcoIwQdYPKqnLEk3h0NxU6YtFgO
# UQoRjL6AxBBjNy7uKLBouFvUH9Niqd1mttZ7cmQwZYS5ZC0CAwEAAaOCARswggEX
# MB0GA1UdDgQWBBQ8/pBBkouVYYbrLhh1OeVsYmMGBTAfBgNVHSMEGDAWgBTVYzpc
# ijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1p
# Y3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0w
# Ny0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAx
# LmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3
# DQEBCwUAA4IBAQA+ZGB4oro9rJL5M1mNbe79wZ8Rvr6mQ+RAgQyFexjgm8DtNb80
# lv6gcSY/t3ofa2zJFoKm3WHknGhJ8YjeNUoGK0QoEW6GRZ84ZORgr2h7+PFm/3cz
# Ync/v8DA+rgXELmHHPgR3I0wT1e3gjI6Zln6WkKs+V/Eky4y9dD8cmO/0eTt262c
# gM3zkld45NttDWSU0naPIBzAaJFFnEGFzrc7fLDmX/D5upcus4XEPDO8rDFPCIfu
# LcfzoJQAClhwSj3Op+9xux2kiy3CfeYZp+Mcm1JOHsZBOOfi5ogpGXRLEFjhO9FM
# Zorf/B3Ocx0ZfwbmS/eJGUnlClCiEZBHbSwEMIIGcTCCBFmgAwIBAgIKYQmBKgAA
# AAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUg
# QXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQAD
# ggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxf
# xcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAiz
# Qt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSm
# XdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR
# 0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcv
# RLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsG
# AQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkr
# BgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUw
# AwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBN
# MEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoG
# CCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkr
# BgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABl
# AGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJ
# KoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76
# V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb
# 3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1
# a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttX
# QOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd
# /DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaK
# D4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQek
# kzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5
# slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN
# 4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA
# /czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkS
# oYICzjCCAjcCAQEwgfihgdCkgc0wgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJX
# QTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0
# ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjhFOUUtNEJEMC0yRUQwMSUwIwYD
# VQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBzZXJ2aWNloiMKAQEwBwYFKw4DAhoD
# FQAK6tw6AElmGynA+7DVP8XOX5EfhqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA4SurGTAiGA8yMDE5MDkxODAy
# NTcyOVoYDzIwMTkwOTE5MDI1NzI5WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDh
# K6sZAgEAMAoCAQACAh5jAgH/MAcCAQACAhFwMAoCBQDhLPyZAgEAMDYGCisGAQQB
# hFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAw
# DQYJKoZIhvcNAQEFBQADgYEAwTsp652egxt6BcXEBdOiZZmX+gFq+xDKICkdle9R
# tLh0PZTaRYTpd/8NJt2U7dqyXg8qSkkKWb2b1x8Yzw+1mw+WnvjbEy7flwVf1QEG
# EDYBhMrHRlkEvERit6LKD2DoLdcFDWatb2nwbWzB2zvelzyJXZTNdW/ehD0mt6fM
# g44xggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAIT
# MwAAAN+ujcXQrkI3zwAAAAAA3zANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcN
# AQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCD4yXrbkKc1DI/hSmYL
# aDyduLh8FP2ZjFCwKv9kprqlyzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0E
# IKHBKe9Xnl1za8prb4tPbhIMCoO3DpFRis8LvOCZiwYvMIGYMIGApH4wfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAADfro3F0K5CN88AAAAAAN8wIgQg
# ESXbKHwgnJkIlr1o/DDoHuiGBnkZPhuXUEuvAs4PRqkwDQYJKoZIhvcNAQELBQAE
# ggEAAuGo9iHdpbvAFxO/rJJPkPJ/gTZybyhc0+IULNWgs/sTkvjY278shfXmmSYh
# 9pou9b3wVoYQByWy/JAXmKpzvYUpE3BOxqVKRqK/Su2jWZ9cS2XlFDEX2kj4LR3j
# ncn4TE+ZtdEf/fPE+SfCG73xIx78u/J7yS+p/epUr13NjxLq82IOWOXPDNVgBtTF
# XbDSSWnDxv3iCyEVuYYTxalshS5m/H1mODeMrrB8cuNwce1gUDpAMwWMTTZL/Pcl
# kNOFXPmxQ484ujx21SqSfTt8dXZWLB20Y4JF3nmAQMtdeftFFicIQmuXoBcjiWOQ
# AkTL/DitehzZeBWi85Xy1jshCw==
# SIG # End signature block
