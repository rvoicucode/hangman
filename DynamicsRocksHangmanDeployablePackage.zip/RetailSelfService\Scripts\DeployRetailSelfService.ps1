<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

param(
    [string]$config = $(Throw 'config parameter required'),
    [string]$log = $(Throw 'log parameter required'))

function Copy-Files(
    [string]$SourceDirPath = $(Throw 'SourceDirPath parameter required'),
    [string]$DestinationDirPath = $(Throw 'DestinationDirPath parameter required'),
    [string]$FilesToCopy = '*',
    [string]$LogFile)
{
    $global:LASTEXITCODE = 0
    $output = robocopy.exe /E $SourceDirPath $DestinationDirPath $FilesToCopy

    $capturedExitCode = $global:LASTEXITCODE

    Write-Log $output -logFile $LogFile

    #Robocopy Exit codes related info: http://support.microsoft.com/kb/954404
    if(($capturedExitCode -ge 0) -and ($capturedExitCode -le 8))
    {
        Write-Log "[Robocopy] completed successfully." -logFile $LogFile
    }
    else
    {
        throw "[Robocopy] failed with exit code $capturedExitCode"
    }
}

function Copy-SelfServiceArtifacts(
    [string]$TargetPackagesPath = $(Throw 'TargetPackagesPath parameter required'),
    [string]$TargetScriptsPath = $(Throw 'TargetScriptsPath parameter required'),
    [string]$SourceDirectory = $(Throw 'SourceDirectory parameter required'),
    [string]$LogFile)
{
    Write-Log "Starting to copy self service artifacts." -logFile $LogFile

    # Source location for self-service packages and scripts
    $sourceSelfServicePkgLocation = Join-Path -Path $SourceDirectory -ChildPath 'Packages'
    $sourceSelfServiceScriptLocation = Join-Path -Path $SourceDirectory -ChildPath 'Scripts'

    Write-Log ("Copying self-service packages from: '{0}' to: '{1}'" -f $sourceSelfServicePkgLocation, $TargetPackagesPath) -logFile $LogFile
    Copy-Files $sourceSelfServicePkgLocation $TargetPackagesPath -logFile  $LogFile

    Write-Log ("Copying self-service scripts from: '{0}' to: '{1}'" -f $sourceSelfServiceScriptLocation, $TargetScriptsPath) -logFile $LogFile
    Copy-Files $sourceSelfServiceScriptLocation $TargetScriptsPath -logFile  $LogFile

    Write-Log "Finished copying self service artifacts." -logFile $LogFile
}

function ConvertDomainUser-ToSID(
    [string]$DomainUser = $(Throw 'DomainUser parameter is required')
)
{
    $domainName = $DomainUser.Split('\')[0]
    $userName = $DomainUser.Split('\')[1]

    $userObject = New-Object System.Security.Principal.NTAccount($domainName, $userName)
    $SIDString = $userObject.Translate([System.Security.Principal.SecurityIdentifier])

    return $SIDString.Value
}

function Add-UserPermissionsToFolder(
    [string]$Folder = $(Throw 'Folder parameter is required'),
    [string]$UserSID = $(Throw 'UserSID parameter is required')
)
{
    $identity = New-Object System.Security.Principal.SecurityIdentifier($UserSID)

    $acl = (Get-Item $Folder).GetAccessControl('Access')
    $aclRule = New-Object System.Security.AccessControl.FileSystemAccessRule($identity,'FullControl','ContainerInherit,ObjectInherit','None','Allow')

    $acl.SetAccessRule($aclRule)
    $acl | Set-Acl $Folder
}

function Configure-SelfServicePackages(
    [string]$SelfServicePackagesDirectory = $(Throw 'SelfServicePackagesDirectory parameter required'),
    [string]$SelfServiceScriptsDirectory = $(Throw 'SelfServiceScriptsDirectory parameter required'),
    [string]$AosWebsiteName = $(Throw 'AosWebsiteName parameter required'),
    [string]$AOSServiceUser = $(Throw 'AOSServiceUser parameter required'),
    [string]$LogFile = $(Throw 'LogFile parameter required'))
{
    # Add permissions for IIS_IUSRS and AOSServiceUser to self-service packages folder.
    Write-Log "Granting permissions to IIS_IUSRS." -logFile $LogFile

    Add-UserPermissionsToFolder -Folder $SelfServicePackagesDirectory -UserSID 'S-1-5-32-568'
    Write-Log ("Finished granting permissions to IIS_IUSRS for '{0}'" -f $SelfServicePackagesDirectory) -logFile $LogFile

    if ([System.String]::Equals($AOSServiceUser, "NETWORK_SERVICE", [System.StringComparison]::OrdinalIgnoreCase))
    {
        # "S-1-5-20" is a well-known SID for NETWORK_SERVICE. Please refer: http://msdn.microsoft.com/en-us/library/cc980032.aspx
        Write-Log "Granting permissions to NETWORK_SERVICE." -logFile $LogFile
        
        Add-UserPermissionsToFolder -Folder $SelfServicePackagesDirectory -UserSID 'S-1-5-20'
        Write-Log ("Finished granting permissions to NETWORK_SERVICE for '{0}'" -f $SelfServicePackagesDirectory) -logFile $LogFile
    }
    else
    {
        $userSID = ConvertDomainUser-ToSID -DomainUser  $AOSServiceUser
        Write-Log ("Granting permissions to '{0}'." -f $AOSServiceUser) -logFile $LogFile

        Add-UserPermissionsToFolder -Folder $SelfServicePackagesDirectory -UserSID $userSID
        Write-Log ("Finished granting permissions to '{0}' for '{1}'" -f $AOSServiceUser, $SelfServicePackagesDirectory) -logFile $LogFile
    }

    # Record Self-Service metadata in registry
    $selfServiceLocationRegistryPath = 'HKLM:\SOFTWARE\Microsoft\Dynamics\7.0\RetailSelfService'
    Write-Log ("Updating self service packages location in registry: '{0}'" -f $selfServiceLocationRegistryPath) -logFile $LogFile

    New-Item -Path $selfServiceLocationRegistryPath -ItemType Directory -Force
    New-ItemProperty -Path $selfServiceLocationRegistryPath -Name (Get-SelfServicePkgLocationRegKeyName) -Value $SelfServicePackagesDirectory
    New-ItemProperty -Path $selfServiceLocationRegistryPath -Name (Get-SelfServiceScriptsLocationRegKeyName) -Value $SelfServiceScriptsDirectory
    New-ItemProperty -Path $selfServiceLocationRegistryPath -Name (Get-SelfServiceAOSWebsiteRegKeyName) -Value $AosWebsiteName

    Write-Log "Finished updating self service packages location in registry." -logFile $LogFile
}

try
{
    $scriptDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
    Import-Module (Join-Path -Path $scriptDir -ChildPath 'SelfServiceConfiguration.psm1') -DisableNameChecking

    $settings = @{}
    if (-not($config))
    {
        Write-Log -objectToLog 'The config parameter cannot be empty!' -logFile $log
        Throw 'The config parameter cannot be empty!'
    }

    # Decode all config values
    Write-Log -objectToLog ("Input configuration string: {0}" -f $config) -logFile $log
    $decodedConfig = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($config))

    $settings = ConvertFrom-Json $decodedConfig
    Write-Log -objectToLog ("Decoded configuration string: {0}" -f $settings) -logFile $log

    # Read all decoded config values
    $AOSWebsiteName = $($settings.AOSWebsiteName)
    $AOSServiceUser = $($settings.AOSServiceUser)

    $targetPackagesFolder = $($settings.PackagesDropLocation)
    $targetScriptsFolder = $($settings.ScriptsDropLocation)

    # Copy Self-Service packages and scripts to correct location
    $retailSelfServiceRootFolder = (Get-Item $scriptDir).Parent.FullName
    Copy-SelfServiceArtifacts -TargetPackagesPath $targetPackagesFolder `
                              -TargetScriptsPath $targetScriptsFolder `
                              -SourceDirectory $retailSelfServiceRootFolder `
                              -LogFile $log

    # Configure Self-Service packages
    Configure-SelfServicePackages -SelfServicePackagesDirectory $targetPackagesFolder `
                                  -SelfServiceScriptsDirectory $targetScriptsFolder `
                                  -AosWebsiteName $AOSWebsiteName `
                                  -AOSServiceUser $AOSServiceUser `
                                  -logFile $log
}
catch
{
    Write-Log ($global:error[0] | Format-List * -Force | Out-String -Width 4096) -logFile $log
    $ScriptLine = "{0}{1}" -f $MyInvocation.MyCommand.Path.ToString(), [System.Environment]::NewLine

    # Set a non-zero unique exit code for RetailSelfService deploy failure
    $exitCode = 24741
    Write-Log ("Executed:{0}$ScriptLine{0}Exiting with error code $exitCode." -f [System.Environment]::NewLine) -logFile $log
    exit $exitCode
}


# SIG # Begin signature block
# MIIjrgYJKoZIhvcNAQcCoIIjnzCCI5sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDc1RVooPUb/Qn2
# RjtBA4HhdyxywkNfVcE3oEW7dv1Ne6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVgzCCFX8CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg5X2EJ4LF
# CXLh5znXANnHpuapXA3A0tmGecBqHk1EwYEwbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQBOJzF7C17C9MUiLQ0hU4claTKDzIy4ZfizdIbv7Z+8MX4IDAYv
# mQKquixPWFBCdi5my/ZrU3B6BGfqL3NCWry80s1EvfIVcK2FLW4inw7KZRV7BE2f
# Dqcy181FFhk2kjLqln8iv/DD0LxgkyrWkYeiyDfLXeS6MVDMXbEvcustg8n89V8l
# CHRcvzPqoHzz3/Ho0X1lqmPZfWCnNGuzI9aOeDQkitLeT96W/8adEy1UxESc2og6
# GtKu+jiJs6ok585pnhuoHYc3e2oLGnc1jY+PPdPiiXJw1WLpfOOY84sYyd/8YIBS
# E14atCCNQjzAaHFFO+DMUqrRm/CRK16ki3DcoYIS4zCCEt8GCisGAQQBgjcDAwEx
# ghLPMIISywYJKoZIhvcNAQcCoIISvDCCErgCAQMxDzANBglghkgBZQMEAgEFADCC
# AU8GCyqGSIb3DQEJEAEEoIIBPgSCATowggE2AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIFsBRysiLWo5KjzCGx7d9QOYhQX6CH7OOauLzV0lFezvAgZd
# XaMYxeUYETIwMTkwOTE3MTkyMDU4LjhaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQg
# QW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo0OUJD
# LUUzN0EtMjMzQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZaCCDjwwggTxMIID2aADAgECAhMzAAAA7vjF9TY7gRyMAAAAAADuMA0GCSqGSIb3
# DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE4MTAyNDIx
# MTQxNVoXDTIwMDExMDIxMTQxNVowgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlv
# bnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ5QkMtRTM3QS0yMzNDMSUwIwYD
# VQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAo/dWNYTz3TTko5NIZbKSabihUcL7UR4IvqWEr/NI
# RptsDNyPw4JLEhGxEVz/IrM+wt632qyTRZH0iv8SFm/SLU/IIHYFITdLn9T9V36p
# 9JEhprmMab/pIbiYDCC3W7TFv0/DbHSGjRD8aP6NDIVkW/AjLdokCwxQtIyPZwIN
# lze0Hx2vi83Vh4wecNPu3yLJ/lSsV/S+zVUS+5ugKeHLVgIuTctyKr9MjBSahCol
# 3xHOgIHqFWBiV6IOGgl0pRit6ZqIVizNr9JpXS/xiBqWEThRDpe93WwRUugypZUX
# pCdJqX44GoQd6OXnzZ9snC9EZRNdiVqAPTxaN379X8arLQIDAQABo4IBGzCCARcw
# HQYDVR0OBBYEFCZ3zTgrRX690zNlKPfP42jyDmVNMB8GA1UdIwQYMBaAFNVjOlyK
# MZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWlj
# cm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3
# LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEu
# Y3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcN
# AQELBQADggEBAJE/4tEVGyAhHPJ7vOSbWQPfjJpcYsQewcXTTpYhYPUD5c+DmJQn
# TV34Gk7spFnjI4csLMhy+MQmw3MGWqf/7f7uoYonxWVoyPYWj1pOcuU38ZGB/Bjk
# bizNlJm12mCgYF92PGRGRf8ZFgxAJX9nuy86/B+/GGxokIytmiNv/ammPimyVx6q
# g4yjGrWV49cLeMmk0Qscu83Fz+MTRVdDDx/BF4YmcS+tJ24R86azcl2Qo92gK3SH
# 93cm2QaPX039Hg97DDTwJVQh5G5LH6t9nZoBgALf9qmmGfkk0qgULjj6IVkz/ptn
# yhB3T2ZOfJe3BFqlBLNWObYvVCHiXMUBqEYwggZxMIIEWaADAgECAgphCYEqAAAA
# AAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBB
# dXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/F
# w+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC
# 3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd
# 0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHR
# D5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9E
# uqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYB
# BAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsG
# AQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTAD
# AQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0w
# S6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYI
# KwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWlj
# Um9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsG
# AQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUA
# ZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkq
# hkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpX
# bRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvc
# XBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr
# 5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA
# 6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38
# ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooP
# iRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6ST
# OvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmy
# W9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3g
# hvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9
# zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKh
# ggLOMIICNwIBATCB+KGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046NDlCQy1FMzdBLTIzM0MxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMV
# ADg9rCZBIo88xsZV2gYK+TJtky5poIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDhKxCIMCIYDzIwMTkwOTE3MTU1
# ODAwWhgPMjAxOTA5MTgxNTU4MDBaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOEr
# EIgCAQAwCgIBAAICGWMCAf8wBwIBAAICEbQwCgIFAOEsYggCAQAwNgYKKwYBBAGE
# WQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDAN
# BgkqhkiG9w0BAQUFAAOBgQCQs/YKC92myvcK43Oq57sFXWZN3iya7hka6qFp1Vfs
# ONq9sMJ99J3SljGwutTSZyhRVfxitDrUMxxAdnmbsdML1VdXUh6640RnDBpuWdTt
# tO1spWTD96KazOO5xoGbA1xTMA3r/Sk6P8/BFV30xSCLDxjQTRpGi/q3XLcNrSlk
# eTGCAw0wggMJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAAA7vjF9TY7gRyMAAAAAADuMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0B
# CQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEID/zH3fl23O+yg4R9Kwf
# YWD8l6NYZbhWt8e9W2us7OmLMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQg
# P67GIrc++/i0sXeTNT6SUQqfCyEB8pkrEgzRIy8QLsMwgZgwgYCkfjB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAO74xfU2O4EcjAAAAAAA7jAiBCDc
# R/8gHpqHoSWex34uqCpooPsOnfKrQbx7vNFFjDFeBzANBgkqhkiG9w0BAQsFAASC
# AQAr4WYyA4ya4Vde+ciVMP/DbeYHt6guZyXyfV4xEkQzc5EE6AWoIGyrBc7UVFjp
# TkU1pjWOBYJVPrbEethOPpEBrhUccWQYbKsPX2fTPYp/ZZkyZdau90IQLX30PI+8
# 3GNYORV00+XtOGNJ/qHf+JjbeV8ejFan/aA+C/Dg1+U/azJ7JUhNm9+5emi3yrmz
# C/qcOuOOUsZMHm42dgpuRWkAviyWD1FfvsnH1PT+F665zuuLzct6GqBnzlMXsXW7
# FSI1cZ1T8CLBugYNdvT5GvA5FfCDbP/dfEVWmTBs1BK/Lvx/d/NHEsDOedGVIhmk
# f9ttf+2DTD0f0lT7uM7vzQ0O
# SIG # End signature block
